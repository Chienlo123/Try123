package instapay

import (
	"encoding/xml"
)

type (
	Schema struct {
		XMLName              xml.Name `xml:"SchemaHead"`
		Xmlns                string   `xml:"xmlns"`
		Xmlnsxs              string   `xml:"xmlnsxs"`
		Xmlnsmr              string   `xml:"xmlnsmr"`
		Xmlnsne              string   `xml:"xmlnsne"`
		Xmlnssr              string   `xml:"xmlnssr"`
		Xmlnsrs              string   `xml:"xmlnsrs"`
		Xmlnsfr              string   `xml:"xmlnsfr"`
		Xmlnsrf              string   `xml:"xmlnsrf"`
		Xmlnser              string   `xml:"xmlnser"`
		Xmlnsre              string   `xml:"xmlnsre"`
		Xmlnsrt              string   `xml:"xmlnsrt"`
		Xmlnshead            string   `xml:"xmlnshead"`
		Xmlnsps              string   `xml:"xmlnsps"`
		Xmlnsct              string   `xml:"xmlnsct"`
		TargetNamespace      string   `xml:"targetnamespace"`
		ElementFormDefault   string   `xml:"elementformdefault"`
		AttributeFormDefault string   `xml:"attributeformdefault"`
		Imports              Imports
		Element1             Element1
		ComplexType          ComplexType
	}

	Imports struct {
		XMLName        xml.Name `xml:"soapenv:Header"`
		Namespace      string   `xml:"namespace"`
		SchemaLocation string   `xml:"schemalocation"`

		Namespace1      string `xml:"namespaces1"`
		SchemaLocation1 string `xml:"schemalocations1"`

		Namespace2      string `xml:"namespace2"`
		SchemaLocation2 string `xml:"schemalocation2"`

		Namespace3      string `xml:"namespace3"`
		SchemaLocation3 string `xml:"schemalocation3"`

		Namespace4      string `xml:"namespace4"`
		SchemaLocation4 string `xml:"schemalocation4"`

		Namespace5      string `xml:"namespace5"`
		SchemaLocation5 string `xml:"schemalocation5"`

		Namespace6      string `xml:"namespace6"`
		SchemaLocation6 string `xml:"schemalocation6"`

		Namespace7      string `xml:"namespace7"`
		SchemaLocation7 string `xml:"schemalocation7"`

		Namespace8      string `xml:"namespace8"`
		SchemaLocation8 string `xml:"schemalocation8"`

		Namespace9      string `xml:"namespace9"`
		SchemaLocation9 string `xml:"schemalocation9"`

		Namespace10      string `xml:"namespace10"`
		SchemaLocation10 string `xml:"schemalocation10"`

		Namespace11      string `xml:"namespace11"`
		SchemaLocation11 string `xml:"schemalocation11"`
	}

	Element1 struct {
		XMLName xml.Name `xml:"Elementhead"`
		Name    string   `xml:"name"`
		Types   string   `xml:"types"`

		Name1  string `xml:"name1"`
		Types1 string `xml:"types1"`
	}

	ComplexType struct {
		XMLName  xml.Name `xml:"soapenv:Body"`
		Name     string   `xml:"name"`
		Sequence Sequence
	}
	Sequence struct {
		XMLName  xml.Name `xml:"Sequencehead"`
		Choice   Choice
		Element1 Element1
	}

	Choice struct {
		XMLName xml.Name `xml:"StudentInformation"`
		Name    string   `xml:"name"`
		Type    string   `xml:"type"`
		Element Element
	}
	Element struct {
		XMLName xml.Name `xml:"Elementhead"`
		Name1   string   `xml:"name1"`
		Types1  string   `xml:"types1"`

		Name2  string `xml:"name2"`
		Types2 string `xml:"types2"`

		Name3  string `xml:"name3"`
		Types3 string `xml:"types3"`

		Name4  string `xml:"name4"`
		Types4 string `xml:"types4"`

		Name5  string `xml:"name5"`
		Types5 string `xml:"types5"`

		Name6  string `xml:"name6"`
		Types6 string `xml:"types6"`

		Name7  string `xml:"name7"`
		Types7 string `xml:"types7"`

		Name8  string `xml:"name8"`
		Types8 string `xml:"types8"`

		Name9  string `xml:"name9"`
		Types9 string `xml:"types9"`

		Name10  string `xml:"name10"`
		Types10 string `xml:"types10"`

		Name11  string `xml:"name11"`
		Types11 string `xml:"types11"`
	}
)

type Schemas struct {
	Xmlns   string
	Xmlnsxs string
	Xmlnsmr string
	Xmlnsne string
	Xmlnssr string
	Xmlnsrs string
}
