package instapay4

import "encoding/xml"

// FIToFICstmrCdtTrf

type Message struct {
	XMLName           xml.Name `xml:"Message"`
	FIToFICstmrCdtTrf FIToFICstmrCdtTrf
}
type FIToFICstmrCdtTrf struct {
	Name              string `xml:"name"`
	ISO_Description   string `xml:"iso_description"`
	Product_Usage     string `xml:"product_usage"`
	Type              string `xml:"type"`
	Rules             string `xml:"rules"`
	Occurrence        string `xml:"occurrence"`
	GrpHdr            GrpHdr
	MsgId             MsgId
	CreDtTm           CreDtTm
	NbOfTxs           NbOfTxs
	TtlIntrBkSttlmAmt TtlIntrBkSttlmAmt
	IntrBkSttlmDt     IntrBkSttlmDt
	SttlmInf          SttlmInf
	CdtTrfTxInf       CdtTrfTxInf
}

type GrpHdr struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Type            string `xml:"type"`
	Rules           string `xml:"rules"`
	Occurrence      string `xml:"occurrence"`
}

type MsgId struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Note            string `xml:"note"`
	Format          string `xml:"format"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Min_MaxLen      string `xml:"min_maxlen"`
	Occurrence      string `xml:"occurrence"`
}

type CreDtTm struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Format          string `xml:"format"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Rules           string `xml:"rules"`
	Reason_Codes    string `xml:"reason_codes"`
	Occurrence      string `xml:"occurrence"`
}

type NbOfTxs struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Note            string `xml:"note"`
	Example         string `xml:"example"`
	RegEx           string `xml:"regex"`
	Type            string `xml:"type"`
	Rules           string `xml:"rules"`
	Reason_Codes    string `xml:"reason_codes"`
	Occurrence      string `xml:"occurrence"`
}

type TtlIntrBkSttlmAmt struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Note            string `xml:"note"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Total_Digits    string `xml:"total_digits"`
	Frac_Digits     string `xml:"frac_digits"`
	Rules           string `xml:"rules"`
	Reason_Codes    string `xml:"reason_codes"`
	Occurrence      string `xml:"occurrence"`
	Ccy             Ccy
}

type Ccy struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Example         string `xml:"example"`
	RegEx           string `xml:"regex"`
	Type            string `xml:"type"`
	Rules           string `xml:"rules"`
	Reason_Codes    string `xml:"reason_codes"`
}

type IntrBkSttlmDt struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Note            string `xml:"note"`
	Format          string `xml:"format"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Rules           string `xml:"rules"`
	Reason_Codes    string `xml:"reason_codes"`
	Occurrence      string `xml:"occurrence"`
}

type SttlmInf struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	SttlmMtd        SttlmMtd
	ClrSys          ClrSys
}

type SttlmMtd struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Note            string `xml:"note"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Rules           string `xml:"rules"`
	Reason_Codes    string `xml:"reason_codes"`
	Occurrence      string `xml:"occurrence"`
}

type ClrSys struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Note            string `xml:"note"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	Cd              Cd
}

type Cd struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Note            string `xml:"note"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Min_MaxLen      string `xml:"min_maxlen"`
	Rules           string `xml:"rules"`
	Reason_Codes    string `xml:"reason_codes"`
	Occurrence      string `xml:"occurrence"`
}

///CdtTrfTxInf

type CdtTrfTxInf struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Note            string `xml:"note"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	PmtId           PmtId
	PmtTpInf        PmtTpInf
	IntrBkSttlmAmt  IntrBkSttlmAmt
	ChrgBr          ChrgBr
	InstgAgt        InstgAgt
	InstdAgt        InstdAgt
	UltmtDbtr       UltmtDbtr
}
type PmtId struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	InstrId         InstrId
	EndToEndId      EndToEndId
	TxId            TxId
	ClrSysRef       ClrSysRef
}
type InstrId struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Format          string `xml:"format"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Min_MaxLen      string `xml:"min_maxlen"`
	Rules           string `xml:"rules"`
	ReasonCodes     string `xml:"reasoncodes"`
	Occurrence      string `xml:"occurrence"`
}

type EndToEndId struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Note            string `xml:"note"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Min_MaxLen      string `xml:"min_maxlen"`
	Occurrence      string `xml:"occurrence"`
}
type TxId struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Note            string `xml:"note"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Min_MaxLen      string `xml:"min_maxlen"`
	Occurrence      string `xml:"occurrence"`
}

type ClrSysRef struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Note            string `xml:"note"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Min_MaxLen      string `xml:"min_maxlen"`
	Rules           string `xml:"rules"`
	ReasonCodes     string `xml:"reasoncodes"`
	Occurrence      string `xml:"occurrence"`
}

///

type PmtTpInf struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	SvcLvl          SvcLvl
	LclInstrm       LclInstrm
	CtgyPurp        CtgyPurp
}
type SvcLvl struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	PmtTpInf_Cd     PmtTpInf_Cd
}
type PmtTpInf_Cd struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Note            string `xml:"note"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Min_MaxLen      string `xml:"min_maxlen"`
	Rules           string `xml:"rules"`
	Reason_Codes    string `xml:"reason_codes"`
	Occurrence      string `xml:"occurrence"`
}
type LclInstrm struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	LclInstrm_Prtry LclInstrm_Prtry
}
type LclInstrm_Prtry struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Note            string `xml:"note"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Min_MaxLen      string `xml:"min_maxlen"`
	Rules           string `xml:"rules"`
	Reason_Codes    string `xml:"reason_codes"`
	Occurrence      string `xml:"occurrence"`
}
type CtgyPurp struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	CtgyPurp_Prtry  CtgyPurp_Prtry
}
type CtgyPurp_Prtry struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Min_MaxLen      string `xml:"min_maxlen"`
	Occurrence      string `xml:"occurrence"`
}

///

type IntrBkSttlmAmt struct {
	Name               string `xml:"name"`
	ISO_Description    string `xml:"iso_description"`
	Product_Usage      string `xml:"product_usage"`
	Note               string `xml:"note"`
	Example            string `xml:"example"`
	Type               string `xml:"type"`
	Total_Digits       string `xml:"total_digits"`
	Frac_Digits        string `xml:"frac_digits"`
	Rules              string `xml:"rules"`
	Reason_Codes       string `xml:"reason_codes"`
	Occurrence         string `xml:"occurrence"`
	IntrBkSttlmAmt_Ccy IntrBkSttlmAmt_Ccy
}

type IntrBkSttlmAmt_Ccy struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Example         string `xml:"example"`
	RegEx           string `xml:"regex"`
	Type            string `xml:"type"`
	Rules           string `xml:"rules"`
	Reason_Codes    string `xml:"reason_codes"`
}

///

type ChrgBr struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Note            string `xml:"note"`
	Example         string `xml:"example"`
	Type            string `xml:"type"`
	Rules           string `xml:"rules"`
	Reason_Codes    string `xml:"reason_codes"`
	Occurrence      string `xml:"occurrence"`
}

///

type InstgAgt struct {
	Name                string `xml:"name"`
	ISO_Description     string `xml:"iso_description"`
	Type                string `xml:"type"`
	Occurrence          string `xml:"occurrence"`
	InstgAgt_FinInstnId InstgAgt_FinInstnId
}

type InstgAgt_FinInstnId struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	InstgAgt_BICFI  InstgAgt_BICFI
}

type InstgAgt_BICFI struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Note            string `xml:"note"`
	Example         string `xml:"example"`
	RegEx           string `xml:"regex"`
	Type            string `xml:"type"`
	Rules           string `xml:"rules"`
	Reason_Codes    string `xml:"reason_codes"`
	Occurrence      string `xml:"occurrence"`
}

// /
type InstdAgt struct {
	Name                string `xml:"name"`
	ISO_Description     string `xml:"iso_description"`
	Type                string `xml:"type"`
	Occurrence          string `xml:"occurrence"`
	InstdAgt_FinInstnId InstdAgt_FinInstnId
}

type InstdAgt_FinInstnId struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	InstdAgt_BICFI  InstdAgt_BICFI
}

type InstdAgt_BICFI struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Note            string `xml:"note"`
	Example         string `xml:"example"`
	RegEx           string `xml:"regex"`
	Type            string `xml:"type"`
	Rules           string `xml:"rules"`
	Reason_Codes    string `xml:"reason_codes"`
	Occurrence      string `xml:"occurrence"`
}

// /
type UltmtDbtr struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	Nm              Nm
	UltmtDbtr_Id    UltmtDbtr_Id
}

type Nm struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Type            string `xml:"type"`
	Min_MaxLen      string `xml:"min_maxlen"`
	Occurrence      string `xml:"occurrence"`
}
type UltmtDbtr_Id struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	PrvtId          PrvtId
}

type PrvtId struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	Othr            Othr
}

type Othr struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Type            string `xml:"type"`
	Occurrence      string `xml:"occurrence"`
	Othr_Id         Othr_Id
}

type Othr_Id struct {
	Name            string `xml:"name"`
	ISO_Description string `xml:"iso_description"`
	Product_Usage   string `xml:"product_usage"`
	Type            string `xml:"type"`
	Min_MaxLen      string `xml:"min_maxlen"`
	Occurrence      string `xml:"occurrence"`
}

///CdtTrfTxInf

type Dbtr struct {
}
type Dbtr_Nm struct {
}
type PstlAdr struct {
}
type StrtNm struct {
}
type BldgNb struct {
}
type PstCd struct {
}
type TwnNm struct {
}
type Ctry struct {
}

type Id struct {
}

//DbtrAcct DbtrAcct

type DbtrAcct struct {
}

//DbtrAgt

type DbtrAgt struct {
}

// CdtrAgt
type CdtrAgt struct {
}

// Cdtr
type Cdtr struct {
}

// CdtrAcct
type CdtrAcct struct {
}

// Purp
type Purp struct {
}

// RltdRmtInf
type RltdRmtInf struct {
}

// RmtInf
type RmtInf struct {
}

// SplmtryData
type SplmtryData struct {
}
