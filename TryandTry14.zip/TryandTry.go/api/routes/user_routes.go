package routes

import (
	"bufio"
	"bytes"
	"database/sql"
	"encoding/json"
	"encoding/xml"
	"io"
	"regexp"
	"time"

	"log"

	"net/http"
	"os"
	instapay "sample/Instapay"
	"sample/db"
	"sample/instapay2"
	"sample/middleware/loggers"

	"sample/model/payload"

	models "sample/models"
	"strings"

	"fmt"

	"github.com/gofiber/fiber/v2"
)

// create another all data in user and also aditional create table in postgres databased
func CreateUser(c *fiber.Ctx) error {
	var user models.User
	if err := c.BodyParser(&user); err != nil {
		return err
	}
	db.DB.Create(&user)
	return c.XML(user)
}

// register account
func RegisterUser(c *fiber.Ctx) error {
	var newUser models.User

	fmt.Println("            ================ REGISTRATION ================")

	reader := bufio.NewReader(os.Stdin)

	fmt.Print("          Enter username: ")
	newUser.Name, _ = reader.ReadString('\n')
	newUser.Name = strings.TrimSpace(newUser.Name)

	fmt.Print("          Enter Lastname: ")
	newUser.Lastname, _ = reader.ReadString('\n')
	newUser.Lastname = strings.TrimSpace(newUser.Lastname)

	fmt.Print("          Enter Address: ")
	newUser.Address, _ = reader.ReadString('\n')
	newUser.Address = strings.TrimSpace(newUser.Address)

	fmt.Print("          Enter Contact: ")
	newUser.Contact, _ = reader.ReadString('\n')
	newUser.Contact = strings.TrimSpace(newUser.Contact)

	fmt.Print("          Enter email: ")
	newUser.Email, _ = reader.ReadString('\n')
	newUser.Email = strings.TrimSpace(newUser.Email)

	fmt.Print("          Enter Password: ")
	newUser.Password, _ = reader.ReadString('\n')
	newUser.Password = strings.TrimSpace(newUser.Password)

	db.DB.Create(&newUser)
	return c.Status(fiber.StatusCreated).XML(newUser)
}

// Display all users
func getUsers(c *fiber.Ctx) error {
	var users []models.User
	db.DB.Find(&users)
	return c.XML(users)
}

func getUser(c *fiber.Ctx) error {
	id := c.Params("id")
	var user models.User
	db.DB.First(&user, id)
	return c.XML(user)
}

// func GetUsers(c *fiber.Ctx) error {
// 	var users []User
// 	db.Find(&users)
// 	return c.JSON(users)
// }

// func UpdateUser(c *fiber.Ctx) error {
// 	id := c.Params("id")
// 	var user models.User
// 	if err := db.DB.First(&user, id).Error; err != nil {
// 		return err
// 	}
// 	if err := c.BodyParser(&user); err != nil {
// 		return err
// 	}
// 	db.DB.Save(&user)
// 	return c.XML(user)
// }

// Update Users
func UpdateUser(c *fiber.Ctx) error {
	id := c.Params("id")
	var user models.User
	if err := db.DB.Where("id = ?", id).First(&user).Error; err != nil {
		return c.Status(fiber.StatusNotFound).XML(fiber.Map{"error": "User not found"})
	}

	fmt.Println("            ================ UPDATE DATA ================")

	reader := bufio.NewReader(os.Stdin)

	fmt.Print("          Enter new username: ")
	user.Name, _ = reader.ReadString('\n')
	user.Name = strings.TrimSpace(user.Name)

	fmt.Print("          Enter new Lastname: ")
	user.Lastname, _ = reader.ReadString('\n')
	user.Lastname = strings.TrimSpace(user.Lastname)

	fmt.Print("          Enter new Address: ")
	user.Address, _ = reader.ReadString('\n')
	user.Address = strings.TrimSpace(user.Address)

	fmt.Print("          Enter new Contact: ")
	user.Contact, _ = reader.ReadString('\n')
	user.Contact = strings.TrimSpace(user.Contact)

	fmt.Print("          Enter new email: ")
	user.Email, _ = reader.ReadString('\n')
	user.Email = strings.TrimSpace(user.Email)

	fmt.Print("          Enter new Password: ")
	user.Password, _ = reader.ReadString('\n')
	user.Password = strings.TrimSpace(user.Password)

	db.DB.Save(&user)
	return c.XML(user)
}

//DELETE USER
// func deleteUser(c *fiber.Ctx) error {
// 	id := c.Params("id")
// 	var user models.User
// 	db.DB.Delete(&user, id)
// 	return nil
// }

// Delete Users
// func deleteUser(c *fiber.Ctx) error {
// 	id := c.Params("id")
// 	var user models.User

// 	if err := db.DB.Where("id = ?", id).First(&user).Error; err != nil {
// 		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{"error": "User not found"})
// 	}

// 	db.DB.Delete(&user)
// 	return c.JSON(fiber.Map{"message": "User deleted"})
// }

func deleteUser(c *fiber.Ctx) error {

	userResponse := models.User{}
	id := c.Params("id")
	var user models.User

	result := db.DB.Debug().Raw("DELETE FROM users WHERE id = ?", id).Scan(&userResponse)

	if result != nil {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"error": "User Deleted"})
	}

	db.DB.Delete(&user)
	return c.JSON(fiber.Map{"message": "User Not Deleted"})
}

//Clone ng user choose any id

func CloneUser(c *fiber.Ctx) error {
	id := c.Params("id")
	var user models.User
	if err := db.DB.Where("id = ?", id).First(&user).Error; err != nil {
		return c.Status(fiber.StatusNotFound).XML(fiber.Map{"error": "User not found"})
	}

	var clonedUser models.User
	clonedUser.Name = "cloned_" + user.Name
	clonedUser.Lastname = "cloned_" + user.Lastname
	clonedUser.Address = "cloned_" + user.Address
	clonedUser.Contact = "cloned_" + user.Contact
	clonedUser.Email = "cloned_" + user.Email
	clonedUser.Password = "cloned_" + user.Password
	db.DB.Create(&clonedUser)

	return c.XML(clonedUser)
}

// xml Create file
func XmlTry(c *fiber.Ctx) error {

	xmlData := models.UsersInfo{

		CorporateID:      "0434235325",
		BranchID:         "fs43",
		TransactionKey:   "fa0328332",
		RequestRefNo:     "00097323214324300214",
		TransactionType:  "bdfsaf",
		RequestTimeStamp: "gfd32gd",
		TerminalID:       "093424254325",
		Address:          "Laguna",
	}
	file, err := os.Create("xmlData.xml")
	if err != nil {
		fmt.Println("Error creating file:", err)
		return nil
	}
	defer file.Close()

	encoder := xml.NewEncoder(file)
	encoder.Indent("", "\t")

	// Encode the Users struct as XML and write to the file and display it
	err = encoder.Encode(xmlData)
	if err != nil {
		fmt.Println("Error encoding XML:", err)

	}
	return nil
}

// this is the xml construct root
func Xml2ndTry(c *fiber.Ctx) error {

	deped := models.Deped{
		School: "Sto Tomas Integraed higschool",

		PrincipalHead: models.PrincipalHead{
			Principal: "Mr james bond",

			TeacherBody: models.TeacherBody{
				Teacher: "teacher",

				Student: models.Student{

					StudentName:  "chienlo",
					StudentID:    "432532532525325",
					Section:      "Rizal",
					MajorSubject: "BSIS",
				},
			},
		},
	}

	xmlInfo, err := xml.MarshalIndent(deped, "", "")
	if err != nil {

		return c.Status(http.StatusInternalServerError).SendString("error generating XML response")
	}

	c.Response().Header.Set("Content-Type", "application/xml")
	return c.Send(xmlInfo)

	// xmlInfo, err := xml.Marshal(xmlData)
	// if err != nil {

	// 	return c.Status(http.StatusInternalServerError).SendString("error generating XML response")
	// }

	// c.Response().Header.Set("Content-Type", "application/xml")
	// return c.Send(xmlInfo)

}

func GetXml(c *fiber.Ctx) error {

	TryReturn, TryErr := json.MarshalIndent(models.User{}, "", "")

	if TryErr != nil {

		return c.SendString(TryErr.Error())
	}

	response, respErr := http.NewRequest(http.MethodGet, "http://127.0.0.1:8080/xmltry123", bytes.NewBuffer(TryReturn))

	if respErr != nil {

		return c.SendString(respErr.Error())
	}

	response.Header.Set("Content-Type", "application/json")
	client := &http.Client{}

	resp, clientErr := client.Do(response)
	if clientErr != nil {

		return c.SendString(clientErr.Error())
	}
	defer resp.Body.Close()

	respBody, readErr := io.ReadAll(resp.Body)
	if readErr != nil {

		return c.SendString(readErr.Error())
	}

	c.Set("Content-Type", "application/json")

	return c.Send(respBody)

}

func GG(c *fiber.Ctx) error {

	fmt.Println("               ====================================")

	fmt.Println("                        LOGIN ACCOUNT:")
	fmt.Print("                Username: ")
	var name string
	fmt.Scanln(&name)

	fmt.Print("                Password: ")
	var password string
	fmt.Scanln(&password)

	fmt.Println("               ====================================")

	var user models.User
	result := db.DB.First(&user, "name = ?", name)
	if result.Error != nil {
		fmt.Println("Invalid credentials")
		os.Exit(1)
	}

	if password != user.Password {
		fmt.Println("Invalid credentials")
		os.Exit(1)
	}

	response := models.LoginResponse{
		Message: fmt.Sprintf("Welcome, %s!", user.Name),
	}

	xmlResponse, err := xml.MarshalIndent(response, "", "  ")
	if err != nil {
		log.Fatal("Failed to generate XML response")
	}

	fmt.Println("Login successful!")
	fmt.Println(string(xmlResponse))

	// db.DB.First(&user)
	// return c.XML(user)

	db.DB.First(&xmlResponse)
	return c.XML(xmlResponse)

}

func Instapay1(c *fiber.Ctx) error {

	instapay := instapay.Schema{

		Xmlns:                "urn:Instapay",
		Xmlnsxs:              "http://www.w3.org/2001/XMLSchema",
		Xmlnsmr:              "urn:iso:std:iso:20022:tech:xsd:admi.002.001.01",
		Xmlnsne:              "urn:iso:std:iso:20022:tech:xsd:admi.004.001.02",
		Xmlnssr:              "urn:iso:std:iso:20022:tech:xsd:admn.001.001.01",
		Xmlnsrs:              "urn:iso:std:iso:20022:tech:xsd:admn.002.001.01",
		Xmlnsfr:              "urn:iso:std:iso:20022:tech:xsd:admn.003.001.01",
		Xmlnsrf:              "urn:iso:std:iso:20022:tech:xsd:admn.004.001.01",
		Xmlnser:              "urn:iso:std:iso:20022:tech:xsd:admn.005.001.01",
		Xmlnsre:              "urn:iso:std:iso:20022:tech:xsd:admn.006.001.01",
		Xmlnsrt:              "urn:iso:std:iso:20022:tech:xsd:camt.056.001.08",
		Xmlnshead:            "urn:iso:std:iso:20022:tech:xsd:head.001.001.01",
		Xmlnsps:              "urn:iso:std:iso:20022:tech:xsd:pacs.002.001.10",
		Xmlnsct:              "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08",
		TargetNamespace:      "urn:Instapay",
		ElementFormDefault:   "qualified",
		AttributeFormDefault: "qualified",

		Imports: instapay.Imports{
			Namespace:      "urn:iso:std:iso:20022:tech:xsd:admi.002.001.01",
			SchemaLocation: "messages_urn_iso_std_iso_20022_tech_xsd_admi.002.001.01.xsd",

			Namespace1:      "urn:iso:std:iso:20022:tech:xsd:admi.004.001.02",
			SchemaLocation1: "messages_urn_iso_std_iso_20022_tech_xsd_admi.004.001.02.xsd",

			Namespace2:      "urn:iso:std:iso:20022:tech:xsd:admn.001.001.01",
			SchemaLocation2: "messages_urn_iso_std_iso_20022_tech_xsd_admn.001.001.01.xsd",

			Namespace3:      "urn:iso:std:iso:20022:tech:xsd:admn.002.001.01",
			SchemaLocation3: "messages_urn_iso_std_iso_20022_tech_xsd_admn.002.001.01.xsd",

			Namespace4:      "urn:iso:std:iso:20022:tech:xsd:admn.003.001.01",
			SchemaLocation4: "messages_urn_iso_std_iso_20022_tech_xsd_admn.003.001.01.xsd",

			Namespace5:      "urn:iso:std:iso:20022:tech:xsd:admn.004.001.01",
			SchemaLocation5: "messages_urn_iso_std_iso_20022_tech_xsd_admn.004.001.01.xsd",

			Namespace6:      "urn:iso:std:iso:20022:tech:xsd:admn.005.001.01",
			SchemaLocation6: "messages_urn_iso_std_iso_20022_tech_xsd_admn.005.001.01.xsd",

			Namespace7:      "urn:iso:std:iso:20022:tech:xsd:admn.006.001.01",
			SchemaLocation7: "messages_urn_iso_std_iso_20022_tech_xsd_admn.006.001.01.xsd",

			Namespace8:      "urn:iso:std:iso:20022:tech:xsd:camt.056.001.08",
			SchemaLocation8: "messages_urn_iso_std_iso_20022_tech_xsd_camt.056.001.08.xsd",

			Namespace9:      "urn:iso:std:iso:20022:tech:xsd:head.001.001.01",
			SchemaLocation9: "messages_urn_iso_std_iso_20022_tech_xsd_head.001.001.01.xsd",

			Namespace10:      "urn:iso:std:iso:20022:tech:xsd:pacs.002.001.10",
			SchemaLocation10: "messages_urn_iso_std_iso_20022_tech_xsd_pacs.002.001.10.xsd",

			Namespace11:      "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08",
			SchemaLocation11: "messaxges_urn_iso_std_iso_20022_tech_xsd_pacs.008.001.08.xsd",
		},

		Element1: instapay.Element1{

			Name:  "Message",
			Types: "HdrAndData",
		},

		ComplexType: instapay.ComplexType{
			Name: "HdrAndData",

			Sequence: instapay.Sequence{

				Element1: instapay.Element1{

					Name1:  "AppHdr",
					Types1: "head:BusinessApplicationHeaderV01",
				},

				Choice: instapay.Choice{

					Element: instapay.Element{

						Name1:  "CreditTransfer",
						Types1: "ct:Document",

						Name2:  "PaymentStatusReport",
						Types2: "ps:Document",

						Name3:  "EchoRequest",
						Types3: "er:Document",

						Name4:  "EchoResponse",
						Types4: "re:Document",

						Name5:  "SignOnRequest",
						Types5: "sr:Document",

						Name6:  "SignOnResponse",
						Types6: "rs:Document",

						Name7:  "SignOffRequest",
						Types7: "fr:Document",

						Name8:  "SignOffResponse",
						Types8: "rf:Document",

						Name9:  "MessageReject",
						Types9: "mr:Document",

						Name10:  "SystemNotificationEvent",
						Types10: "ne:Document",

						Name11:  "ReturnOfFunds",
						Types11: "rt:Document",
					},
				},
			},
		},
	}

	// xmlInfo, err := xml.MarshalIndent(instapay, " ", "")
	// if err != nil {

	// 	return c.Status(http.StatusInternalServerError).SendString("error generating XML response")
	// }

	// c.Response().Header.Set("Content-Type", "application/xml")
	// return c.Send(xmlInfo)

	file, err := os.Create("xmlData.xml")
	if err != nil {
		fmt.Println("Error creating file:", err)
		return nil
	}
	defer file.Close()

	encoder := xml.NewEncoder(file)
	encoder.Indent("", "\t")

	// Encode the Users struct as XML and write to the file and display it
	err = encoder.Encode(instapay)
	if err != nil {
		fmt.Println("Error encoding XML:", err)

	}
	return nil

}

func Instapay2(c *fiber.Ctx) error {

	instapay := instapay2.AppHdr{

		Name:           "Business Application Header V01",
		ISODescription: "The Business Layer deals with Business Messages. The behaviour of the Business Messages is fully described by the Business Transaction and the structure of the Business Messages is fully described by the Message Definitions and related MessageRules, Rules and Market Practices. All of which are registered in the ISO 20022 Repository.A single new Business Message (with its accompagnying business application header) is created - by the sending MessagingEndpoint - for each business event; that is each interaction in a Business Transaction. A Business Message adheres to the following principles:A Business Message (and its business application header) must not contain information about the Message Transport System or the mechanics or mechanism of message sending, transportation, or receipt.A Business Message must be comprehensible outside of the context of the Transport Message. That is the Business Message must not require knowledge of the Transport Message to be understood.A Business Message may contain headers, footers, and envelopes that are meaningful for the business. When present, they are treated as any other message content, which means that they are considered part of the Message Definition of the Business Message and as such will be part of the ISO 20022 Repository.A Business Message refers to Business Actors by their Name. Each instance of a Business Actor has one Name. The Business Actor must not be referred to in the Transport Layer.Specific usage of this BusinessMessageHeader may be defined by the relevant SEG.",
		Type:           "BusinessApplicationHeaderV01",
		Occurence:      "[1..1]",

		Fr: instapay2.Fr{

			Name:           "From",
			ISODescription: "The sending MessagingEndpoint that has created this Business Message for the receiving MessagingEndpoint that will process this Business Message.Note: The sending MessagingEndpoint might be different from the sending address potentially contained in the transport header (as defined in the transport layer).",
			ProductUsage:   "For identifying the sender of the message. This could be the Participating Bank or InstaPay IPS.",
			Type:           "Party9Choice",
			Occurence:      "[1..1]",

			Fr_FIId: instapay2.Fr_FIId{

				Name:           "Financial Institution Identification",
				ISODescription: "Identification of a financial institution.",
				Type:           "BranchAndFinancialInstitutionIdentification5",
				Occurence:      "[1..1]",

				Fr_FIId_FinInstnId: instapay2.Fr_FIId_FinInstnId{
					Name:           "Financial Institution Identification",
					ISODescription: "Unique and unambiguous identification of a financial institution, as assigned under an internationally recognised or proprietary identification scheme.",
					Type:           "FinancialInstitutionIdentification8",
					Occurence:      "[1..1]",

					Fr_FinInstnId_BICFI: instapay2.Fr_FinInstnId_BICFI{
						Name:           "BICFI",
						ISODescription: "Code allocated to a financial institution by the ISO 9362 Registration Authority as described in ISO 9362 Banking - Banking telecommunication messages - Business identifier code (BIC).",
						ProductUsage:   "For identifying the sender of the message. This could be the BIC of Participating Bank, or the Switch (InstaPay IPS).",
						Example:        "BANKPHPHXXX",
						RegEx:          "[A-Z]{6,6}[A-Z2-9][A-NP-Z0-9]([A-Z0-9]{3,3}){0,1}",
						Type:           "BICFIIdentifier",
						Rule:           "Member identification validation: - Must be the registered identification number of the Participating Bank or InstaPay IPS.- If the 'To' field is the Participant Identifier of the InstaPay IPS, then this field must be a valid Participating Bank",
						ReasonCode:     "Reject with code 'RC01' for all Business Messages in a Message Status Report (pacs.002)for failing validation. Reject with code '9964' a Sign-on request (admn.001) with Sign-on response (admn.002). Reject with code '9964' a Sign-off request (admn.003) with Sign-off response (admn.004).Reject with code '650' in Administration Advice message (admi.002) for failing validation on these fields and message is ignored for Echo request (admn.005), Admin advice (admi.002) and Message Status Report (pacs.002).",
						Occurence:      "[1..1]",
					},
				},

				Fr_FIId_BrnchId: instapay2.Fr_FIId_BrnchId{

					Name:           "Branch Identification",
					ISODescription: "Identifies a specific branch of a financial institution.Usage: This component should be used in case the identification information in the financial institution component does not provide identification up to branch level.",
					ProductUsage:   "This element will be only filled by InstaPay IPS to provide additional information about the original sender and is provided in the following messages:- pacs.008- camt.056",
					Note:           "This information will be needed in the correspondent response messages.",
					Type:           "BranchData2",
					Occurrence:     "[0..1]",

					Fr_FIId_BrnchId_Id: instapay2.Fr_FIId_BrnchId_Id{

						Name:           "Identification",
						ISODescription: "Unique and unambiguous identification of a branch of a financial institution.",
						ProductUsage:   "Participant Identifier of the sender of the message only provided by the Switch (InstaPay IPS).",
						Note:           "This field will be in the structure of a BIC Identification element.",
						Type:           "Max35Text",
						Min_MaxLen:     "1..35",
						Occurrence:     "[1..1]",
					},
				},
			},
		},

		To: instapay2.To{

			Name:           "To",
			ISODescription: "The MessagingEndpoint designated by the sending MessagingEndpoint to be the recipient who will ultimately process this Business Message.Note: The receiving MessagingEndpoint might be different from the receiving address potentially contained in the transport header (as defined in the transport layer).",
			ProductUsage:   "For identifying the receiver of the message. This could be the Participating Bank or InstaPay IPS.",
			Type:           "Party9Choice",
			Occurrence:     "[1..1]",

			To_FIId: instapay2.To_FIId{

				Name:           "Financial Institution Identification",
				ISODescription: "Identification of a financial institution.",
				Type:           "BranchAndFinancialInstitutionIdentification5",
				Occurrence:     "[1..1]",

				To_FIId_FinInstnId: instapay2.To_FIId_FinInstnId{

					Name:           "Financial Institution Identification",
					ISODescription: "Unique and unambiguous identification of a financial institution, as assigned under an internationally recognised or proprietary identification scheme.",
					Type:           "FinancialInstitutionIdentification8",
					Occurrence:     "[1..1]",

					To_FIId_FinInstnId_BICFI: instapay2.To_FIId_FinInstnId_BICFI{

						Name:           "BICFI",
						ISODescription: "Code allocated to a financial institution by the ISO 9362 Registration Authority as described in ISO 9362 Banking - Banking telecommunication messages - Business identifier code (BIC).",
						ProductUsage:   "For identifying the receiver of the message. This could be the Participating Bank or the Switch (InstaPay IPS).",
						Example:        "BANKPHPHXXX",
						RegEx:          "[A-Z]{6,6}[A-Z2-9][A-NP-Z0-9]([A-Z0-9]{3,3}){0,1}",
						Type:           "BICFIIdentifier",
						Rule:           "BIC validation:- Must be the registered identification number of the Participating Bank- If the 'To' field is the Participant Identifier of InstaPay IPS, then this field must be a valid Participating Bank",
						Reason:         "Reject with code 'RC01' for all Business Messages in a Message Status Report (pacs.002)for failing validation Reject with code '9964' a Sign-on request (admn.001) with Sign-on response (admn.002) Reject with code '9964' a Sign-off request (admn.003) with Sign-off response (admn.004)Reject with code '650' in Administration Advice message (admi.002) for failing validation on these fields and message is ignored for Echo request (admn.005), Admin advice (admi.002) and Message Status Report (pacs.002).",
						Occurrence:     "[1..1]",
					},
				},

				To_FIId_BrnchId: instapay2.To_FIId_BrnchId{

					Name:           "Branch Identification",
					ISODescription: "Identifies a specific branch of a financial institution.Usage: This component should be used in case the identification information in the financial institution component does not provide identification up to branch level.",
					ProductUsage:   "This is a conditional field for response messages, in the instances when the BranchId in the 'FROM' element of the incoming request from InstaPay IPS was populated. If this is the case, the content of the BranchId in the 'FROM' element of the original request message must be copied into this field within the outgoing response message. For example, when the BranchId in the 'FROM' element of a pacs.008 is populated in the message received, the responding pacs.002 message sent will include an exact copy of that data in this element.",
					Type:           "BranchData2",
					Occurrence:     "[0..1]",

					To_FIId_BrnchId_Id: instapay2.To_FIId_BrnchId_Id{

						Name:           "Identification",
						ISODescription: "Unique and unambiguous identification of a branch of a financial institution.",
						ProductUsage:   "This is used to provide the Participant Identifier of the original sender in the response message.",
						Note:           "This field is mandatory for the sending Participating Bank in the corresponding response message if the information under the element Fr/FIId/BrnchId/Id was provided in the originally received message. This received information needs to be copied into this element.This field will be in the structure of a BIC Identification element.",
						Type:           "Max35Text",
						Min_MaxLen:     "1..35",
						Rule:           "Mandatory provision of the original sender in the form of the 3 character Participant Identifier if received in the originally message from InstaPay IPS.",
						ReasonCode:     "Reject with code '650' in Administration Advice message admi.002 for failing validation on this field.",
						Occurrence:     "[1..1]",
					},
				},
			},
		},

		BizMsgIdr: instapay2.BizMsgIdr{

			Name:           "Business Message Identifier",
			ISODescription: "Unambiguously identifies the Business Message to the MessagingEndpoint that has created the Business Message.",
			ProductUsage:   "The end-point to end-point identification of the Business Message for each leg (e.g. Instructing Bank to IPS Switch, IPS Switch to Instructed Bank). This identifier is located in the BAH. It is assigned by the sender of the message, that is either the Instructing bank (or a Third Party Service Provider for the Bank) or IPS Switch.",
			Format:         "Format: BYYYYMMDD<BIC-11>X<unique identifier customer specific> Pos. 01-01: fixed value 'B' Pos. 02-09: File creation date in format YYYYMMDD Pos. 10-20: BIC (11 characters) Pos. 21-21: Message generation source ('B' if generated by a Participant, 'G' if generated by a Gateway or API via BancNet Adaptor, 'H' if generated by the InstaPay IPS) Pos. 22-22: 'S' if pacs.008 or 'R' if pacs.002 Pos. 23-35: Message serial number (13 characters)",
			Example:        "B20190308BANKPHPHXXXB0000002344",
			Type:           "Max35Text",
			Min_MaxLen:     "1 .. 35",
			Occurrence:     "[1..1]",
		},

		MsgDefIdr: instapay2.MsgDefIdr{

			Name:           "Message Definition Identifier",
			ISODescription: "Contains the MessageIdentifier that defines the BusinessMessage. It must contain a MessageIdentifier published on the ISO 20022 website.Example: camt.001.001.03",
			ProductUsage:   "Contains the Message Definition Identifier. There are additional proprietary non-ISO schema identifiers that are used within IPS (e.g. admn messages).",
			Type:           "OrigMsgName",
			Min_MaxLen:     "1..35",
			Occurrence:     "[1..1]",
		},

		CreDt: instapay2.CreDt{

			Name:           "Creation Date",
			ISODescription: "Date and time when this Business Message (header) was created. Note: Times must be normalized, using the Z annotation.",
			ProductUsage:   "Date and time when this Business Message (header) was created.",
			Example:        "2015-11-19T00:10:00Z",
			RegEx:          ".*",
			Type:           "ISONormalisedDateTime",
			Occurrence:     "[1..1]",
		},

		CpyDplct: instapay2.CpyDplct{

			Name:           "Copy Duplicate",
			ISODescription: "Indicates whether the message is a Copy, a Duplicate or a copy of a duplicate of a previously sent ISO 20022 Message.",
			ProductUsage:   "This element has a dual purpose. Firstly it is used to identify the Repeat Request for Business Messages in the event of a time- out and secondly in the Message Status Report where ‘DUPL’ was present in the original request.",
			Example:        "DUPL",
			Type:           "CopyDuplicate1Code",
			Rule:           "- Used for Repeat Requests for all Business Messages in the event of a time-out and in therefore present request from the Sending Party to InstaPay IPS.- Used for Message Status Report where 'DUPL' was present in the request",
			ReasonCode:     "Reject with code '650' in Administration Advice message (admi.002) if code is invalid.",
			Occurrence:     "[0..1]",
		},

		Sgntr: instapay2.Sgntr{

			Name:           "Signature",
			ISODescription: "Contains the digital signature of the Business Entity authorised to sign this Business Message.",
			ProductUsage:   "The XML signature applied to the Business Message The default value will be populated by the signing libraries supporting the W3C standard.",
			Type:           "SignatureEnvelope",
			Rule:           "The XML Signature namespace (http://www.w3.org/2000/09/xmldsig#) allows for different XML elements to be root elements . This means the user has to choose amongst these global elements which one to use as the root element. Only the XML element Signature is allowed.",
			Occurrence:     "[1..1]",

			Any: instapay2.Any{

				Occurrence: "[1..1]",
			},
		},
	}

	xmlInfo, err := xml.MarshalIndent(instapay, " ", "")
	if err != nil {

		return c.Status(http.StatusInternalServerError).SendString("error generating XML response")
	}

	c.Response().Header.Set("Content-Type", "application/xml")
	return c.Send(xmlInfo)

	// file, err := os.Create("xmlData.xml")
	// if err != nil {
	// 	fmt.Println("Error creating file:", err)
	// 	return nil
	// }
	// defer file.Close()

	// encoder := xml.NewEncoder(file)
	// encoder.Indent("", "\t")

	// // Encode the Users struct as XML and write to the file and display it
	// err = encoder.Encode(instapay)
	// if err != nil {
	// 	fmt.Println("Error encoding XML:", err)

	// }
	// return nil

}

func Getinstapay2(c *fiber.Ctx) error {

	TryReturn, TryErr := xml.MarshalIndent(instapay2.AppHdr{}, "", "")

	if TryErr != nil {

		return c.SendString(TryErr.Error())
	}

	response, respErr := http.NewRequest(http.MethodPost, "http://127.0.0.1:3000/instapay2", bytes.NewBuffer(TryReturn))

	if respErr != nil {

		return c.SendString(respErr.Error())
	}

	response.Header.Set("Content-Type", "application/xml")
	client := &http.Client{}

	resp, clientErr := client.Do(response)
	if clientErr != nil {

		return c.SendString(clientErr.Error())
	}
	defer resp.Body.Close()

	// respBody, readErr := io.ReadAll(resp.Body)
	// if readErr != nil {

	// 	return c.SendString(readErr.Error())
	// }

	c.Set("Content-Type", "application/xml")

	return c.Send(TryReturn)

}

// func Getinstapay3(c *fiber.Ctx) error {

// 	TryReturn, TryErr := xml.MarshalIndent(instapay3.AdmnSignOnReq{}, "", "")

// 	if TryErr != nil {

// 		return c.SendString(TryErr.Error())
// 	}

// 	response, respErr := http.NewRequest(http.MethodPost, "http://127.0.0.1:3000/instapay3", bytes.NewBuffer(TryReturn))

// 	if respErr != nil {

// 		return c.SendString(respErr.Error())
// 	}

// 	response.Header.Set("Content-Type", "application/xml")
// 	client := &http.Client{}

// 	resp, clientErr := client.Do(response)
// 	if clientErr != nil {

// 		return c.SendString(clientErr.Error())
// 	}
// 	defer resp.Body.Close()

// 	respBody, readErr := io.ReadAll(resp.Body)
// 	if readErr != nil {

// 		return c.SendString(readErr.Error())
// 	}

// 	c.Set("Content-Type", "application/xml")

// 	return c.Send(respBody)

// }

// <message>
//     <AppHdr>
//         <Fr>
//             <FIld>
//                 <IFininstnld>
//                     <BICFI>CMXPH002</BICFI>
//                 </IFininstnld>
//                 <Brnchld>
//                      <Id>CMXPH001</Id>
//                 </Brnchld>
//             </FIld>
//         </Fr>
//         <To>
//             <FIld>
//                 <IFininstnld>
//                     <BICFI>CMXPH002</BICFI>
//                 </IFininstnld>
//                 <Brnchld>
//                      <Id>CMXPH001</Id>
//                 </Brnchld>
//             </FIld>
//         </To>
//         <BizMsgldr>MSDFSDFLKJ20303049234</BizMsgldr>
//     </AppHdr>
// </message>

// func Generate(senderBIC, receivingBIC, businessMessageID, messageDefinitionID, creationDateTime string) instapay.Schema {
// 	// Message structure for digest value
// 	digestApplicationHeader := instapay.Schema{
// 		Xmlns:   senderBIC,
// 		Xmlnsxs: receivingBIC,
// 		Xmlnsmr: businessMessageID,
// 		Xmlnsne: messageDefinitionID,
// 		Xmlnssr: creationDateTime,
// 		Xmlnsrs: "", // You can set this field as needed
// 	}

// 	return digestApplicationHeader
// }

// Define the instapay.Schema struct based on your application

// Generate generates an instapay.Schema based on the provided parameters
func Generate(senderBIC, receivingBIC, businessMessageID, messageDefinitionID, creationDateTime string) instapay.Schemas {
	// Message structure for digest value
	digestApplicationHeader := instapay.Schemas{
		Xmlns:   senderBIC,
		Xmlnsxs: receivingBIC,
		Xmlnsmr: businessMessageID,
		Xmlnsne: messageDefinitionID,
		Xmlnssr: creationDateTime,
		Xmlnsrs: "", // You can set this field as needed
	}

	return digestApplicationHeader
}

func Wew(c *fiber.Ctx) error {
	// Call the Generate function to create an instapay.Schema
	result := Generate("SenderBIC", "ReceivingBIC", "BusinessMessageID", "MessageDefinitionID", "CreationDateTime")

	// Return the generated Schema as JSON
	return c.XML(result)

	// Start the Fiber server on port 3000

}

func HH(c *fiber.Ctx) error {
	// Create a log file named "ediwow.log"
	logFile, err := os.Create("ediwow.log")
	if err != nil {
		log.Fatal("Unable to create log file:", err)
	}
	defer logFile.Close()

	// Create a custom logger
	logger := log.New(logFile, "", log.LstdFlags)

	// Call another function to perform logging
	performLogging(logger)
	return c.XML(logFile)
}

func performLogging(logger *log.Logger) {
	// Log messages using the provided logger
	logger.Println("This is a log message from another function.")
	hostname, err := os.Hostname()
	if err != nil {
		log.Fatal("Unable to get hostname:", err)
	}

	// Log messages with the hostname
	logger.Printf("Hostname: %s", hostname)

}

func Wtf(c *fiber.Ctx) error {
	// Create a log file named "app.log"
	logFile, err := os.Create("app.log")
	if err != nil {
		log.Fatal("Unable to create log file:", err)
	}
	defer logFile.Close()

	// Create a custom logger
	logger := log.New(logFile, "", log.LstdFlags)

	// Get the hostname
	hostname, err := os.Hostname()
	if err != nil {
		log.Fatal("Unable to get hostname:", err)
	}

	// Log messages with the hostname
	logger.Printf("Hostname: %s", hostname)
	logger.Println("This is a log message with the hostname.")

	return c.XML(logFile)
}

func Ins(c *fiber.Ctx) error {

	Info := models.Info{

		ReferenceNumber: "AS4290345669",
		AccountNumber:   "account_number",
		StartDate:       "20200229",
		EndDate:         "20200229",
	}

	return c.JSON(Info)
}

func Instapay123(c *fiber.Ctx) error {

	TryReturn, TryErr := json.MarshalIndent(models.User{}, "", "")

	if TryErr != nil {

		return c.SendString(TryErr.Error())
	}

	response, respErr := http.NewRequest(http.MethodGet, "https://rbi-sandbox.fortress-asya.com/openapi/v1/trxCashOut", bytes.NewBuffer(TryReturn))

	if respErr != nil {

		return c.SendString(respErr.Error())
	}

	response.Header.Set("Content-Type", "application/json")
	client := &http.Client{}

	resp, clientErr := client.Do(response)
	if clientErr != nil {

		return c.SendString(clientErr.Error())
	}
	defer resp.Body.Close()

	respBody, readErr := io.ReadAll(resp.Body)
	if readErr != nil {

		return c.SendString(readErr.Error())
	}

	c.Set("Content-Type", "application/json")

	return c.JSON(respBody)

}

func CT_Transaction(c *fiber.Ctx) error {

	var transactions []models.User123

	result := db.DB.Debug().Raw("SELECT * FROM users WHERE name = 'chienlo'  Limit 1 ").Scan(&transactions)

	if result.Error != nil {

		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"error": "Transactions not foundsss",
		})
	}

	if len(transactions) == 0 {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"error": "No transactions found with status 'FAILED'",
		})
	}

	return c.JSON(transactions)
}

// func CT_Transaction(c *fiber.Ctx) error {

// 	userResponse := models.User{}

// 	name := c.Params("name")
// 	var user models.User

// 	// result := db.DB.Debug().Raw("SELECT * FROM Users WHERE password = '123' ", password, id).Scan(userResponse)
// 	result := db.DB.Debug().Raw("SELECT * FROM Users WHERE name = 'chienlo'", name).Scan(userResponse)

// 	//result := db.DB.Debug().Raw("DELETE FROM users WHERE id = ?", id).Scan(&userResponse)

// 	if result != nil {
// 		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
// 			"error": "Transaction is Found"})
// 	}

// 	db.DB.Find(&user)
// 	return c.XML(fiber.Map{"message": "Transaction is not found"})

// }

// func deleteUser(c *fiber.Ctx) error {

// 	userResponse := models.User{}
// 	id := c.Params("id")
// 	var user models.User

// 	result := db.DB.Debug().Raw("DELETE FROM users WHERE id = ?", id).Scan(&userResponse)

// 	if result != nil {
// 		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
// 			"error": "User Deleted"})
// 	}

// 	db.DB.Delete(&user)
// 	return c.JSON(fiber.Map{"message": "User Not Deleted"})
// }

//function get users
// func CT_Transaction(c *fiber.Ctx) error {

// 	userResponse := payload.CT_Transaction{}
// 	status := c.Params("status")
// 	var user payload.CT_Transaction

// 	result := database.DBConn.Debug().Raw("SELECT * FROM rbi_instapay.ct_transaction WHERE status = 'FAILED' ", status).Scan(userResponse)

// 	//result := db.DB.Debug().Raw("DELETE FROM users WHERE id = ?", id).Scan(&userResponse)

// 	if result != nil {
// 		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
// 			"error": "Transaction is Found"})

// 	}

// 	database.DBConn.Find(&user)
// 	return c.JSON(fiber.Map{"message": "Transaction is not Found"})

// }

func CT(c *fiber.Ctx) error {

	var transactions []models.CT

	result := db.DB.Debug().Raw("SELECT * FROM rbi_instapay.ct_transaction WHERE status = ?", "FAILED").Scan(&transactions)

	if result.Error != nil {

		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"error": "Transactions not foundsss",
		})
	}

	if len(transactions) == 0 {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"error": "No transactions found with status 'FAILED'",
		})
	}

	return c.JSON(transactions)
}

// func main() {
// 	// Define the PostgreSQL database connection parameters.
// 	const (
// 		host     = "your-database-host"
// 		port     = 5432
// 		user     = "your-database-username"
// 		password = "your-database-password"
// 		dbname   = "your-database-name"
// 	)

// 	// Create the database connection string.
// 	connStr := fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=disable", host, port, user, password, dbname)

// 	// Connect to the PostgreSQL database.
// 	db, err := sql.Open("postgres", connStr)
// 	if err != nil {
// 		log.Fatal(err)
// 	}
// 	defer db.Close()

// 	// Prepare and execute the SQL query.
// 	query := `
//         SELECT ct.id, ct.transaction_type, ct.status, ct.reason_code, reason.description,
//                ct.local_instrument, ct.instruction_id, ct.transaction_id, ct.reference_id,
//                ct.sender_bic, ct.sender_name, ct.sender_account, ct.currency, ct.amount,
//                ct.receiving_bic, ct.receiving_name, ct.receiving_account, ct.transaction_datetime, ct.bn_response
//         FROM rbi_instapay.ct_transaction ct
//         LEFT JOIN rbi_instapay.reason_code reason ON ct.reason_code = reason.code
//         WHERE ct.status = 'FAILED'
//     `

// 	rows, err := db.Query(query)
// 	if err != nil {
// 		log.Fatal(err)
// 	}
// 	defer rows.Close()

// 	// Process the query results.
// 	for rows.Next() {
// 		var (
// 			id              int
// 			transactionType string
// 			status          string
// 			reasonCode      string
// 			description     sql.NullString
// 			localInstrument string
// 			// Add more variables for other columns as needed
// 		)

// 		if err := rows.Scan(&id, &transactionType, &status, &reasonCode, &description,
// 			&localInstrument /* Add more variables here */); err != nil {
// 			log.Fatal(err)
// 		}

// 		// Use the retrieved data as needed (e.g., print it).
// 		fmt.Printf("ID: %d, Type: %s, Status: %s, Reason Code: %s, Description: %s\n",
// 			id, transactionType, status, reasonCode, description.String)
// 	}

// 	// Check for errors from iterating over rows.
// 	if err := rows.Err(); err != nil {
// 		log.Fatal(err)
// 	}
// }

func HHp(c *fiber.Ctx) error {
	// Replace these variables with your actual database connection details.
	dbConnStr := "your-database-connection-string"

	// Call the function to fetch data from the database.
	transactions, err := getFailedTransactions(dbConnStr)
	if err != nil {
		log.Fatal(err)
	}

	// Process the fetched data as needed.
	for _, transaction := range transactions {
		fmt.Printf("ID: %d, Type: %s, Status: %s, Reason Code: %s, Description: %s\n",
			transaction.ID, transaction.TransactionType, transaction.Status,
			transaction.ReasonCode, transaction.Description.String)
	}

	return nil
}

// Transaction represents a single transaction record.
type Transaction struct {
	ID                  int
	TransactionType     string
	Status              string
	ReasonCode          string
	Description         sql.NullString
	LocalInstrument     string
	InstructionID       string
	TransactionID       string
	ReferenceID         string
	SenderBIC           string
	SenderName          string
	SenderAccount       string
	Currency            string
	Amount              float64
	ReceivingBIC        string
	ReceivingName       string
	ReceivingAccount    string
	TransactionDatetime string
	BNResponse          string
}

func getFailedTransactions(dbConnStr string) ([]Transaction, error) {
	// Establish a database connection.
	db, err := sql.Open("postgres", dbConnStr)
	if err != nil {
		return nil, err
	}
	defer db.Close()

	// Prepare and execute the SQL query.
	query := `
		SELECT ct.id, ct.transaction_type, ct.status, ct.reason_code, reason.description,
			ct.local_instrument, ct.instruction_id, ct.transaction_id, ct.reference_id,
			ct.sender_bic, ct.sender_name, ct.sender_account, ct.currency, ct.amount,
			ct.receiving_bic, ct.receiving_name, ct.receiving_account, ct.transaction_datetime, ct.bn_response
		FROM rbi_instapay.ct_transaction ct
		LEFT JOIN rbi_instapay.reason_code reason ON ct.reason_code = reason.code
		WHERE ct.status = 'FAILED'
	`

	rows, err := db.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	// Process the query results and store them in a slice of Transaction.
	var transactions []Transaction
	for rows.Next() {
		var transaction Transaction
		if err := rows.Scan(&transaction.ID, &transaction.TransactionType, &transaction.Status,
			&transaction.ReasonCode, &transaction.Description, &transaction.LocalInstrument,
			&transaction.InstructionID, &transaction.TransactionID, &transaction.ReferenceID,
			&transaction.SenderBIC, &transaction.SenderName, &transaction.SenderAccount,
			&transaction.Currency, &transaction.Amount, &transaction.ReceivingBIC,
			&transaction.ReceivingName, &transaction.ReceivingAccount,
			&transaction.TransactionDatetime, &transaction.BNResponse); err != nil {
			return nil, err
		}
		transactions = append(transactions, transaction)
	}

	if err := rows.Err(); err != nil {
		return nil, err
	}

	return transactions, nil
}

func James(c *fiber.Ctx) error {
	// Create a Fiber instance

	// Define an endpoint to retrieve and display the log data

	// Read the log file
	logData, err := os.ReadFile("ggwp/james/ediwow.log")
	if err != nil {
		return c.Status(http.StatusInternalServerError).JSON(fiber.Map{
			"error": "Error reading log file",
		})
	}

	// Send the log data as a response
	return c.Status(http.StatusOK).SendString(string(logData))

}

func Database(c *fiber.Ctx) error {
	// PostgreSQL database configuration

	userResponse := models.Logss{}

	// Create an array to store log file names
	logFiles := []string{"a.log", "ggwp/james/ediwow.log"} // Add your log file names here

	// Create a new Fiber instance

	// Define a route to retrieve and combine log data

	// Create a string to store combined log data
	var combinedLogs strings.Builder

	// Loop through log files and read their content
	for _, fileName := range logFiles {
		logData, err := os.ReadFile(fileName)
		if err != nil {
			combinedLogs.WriteString(fmt.Sprintf("Error reading %s: %v\n", fileName, err))
		} else {
			combinedLogs.WriteString(fmt.Sprintf("Log file: %s\n%s\n\n", fileName, string(logData)))
			// userResponse := models.User{}
			// id := c.Params("id")
			// var user models.User

			// result := db.DB.Debug().Raw("DELETE FROM users WHERE id = ?", id).Scan(&userResponse)

			// if result != nil {
			// 	return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			// 		"error": "User Deleted"})
			// }

			// db.DB.Delete(&user)
			// return c.JSON(fiber.Map{"message": "User Not Deleted"})

			// Store log data in PostgreSQL

			result := db.DB.Debug().Raw("INSERT INTO logs (notification) VALUES (?)", string(logData)).Scan(&userResponse)

			if result != nil {
				log.Printf("Error storing log data in PostgreSQL: %v", err)

				db.DB.Find(&combinedLogs)
			}
		}
	}

	// Send the combined log data as a response
	return c.Status(http.StatusOK).SendString(combinedLogs.String())

	// Start the Fiber server on port 3000

}

// func Get_Notification(c *fiber.Ctx) error {
// 	// Create a slice to store log entries
// 	var logEntries []models.Logs
// 	Log_Response := models.Logs{}

// 	// Create an array to store log file names
// 	// display different logs you want to instore in database and display in postman
// 	logFiles := []string{"ggwp/james/ediwow.go", "a.log"}

// 	// Loop through log files and read their content
// 	for _, fileName := range logFiles {
// 		logData, err := os.ReadFile(fileName)
// 		if err != nil {
// 			log.Printf("Error reading %s: %v\n", fileName, err)
// 		} else {
// 			// Parse log entries and add them to logEntries
// 			log.Printf("Log Notification : %s: %v\n", fileName, string(logData))
// 			entries := parseLogNotification(string(logData))
// 			logEntries = append(logEntries, entries...)
// 		}
// 	}

// 	// Insert log entries into the PostgreSQL database
// 	for _, entry := range logEntries {

// 		result := database.DBConn.Debug().Raw("INSERT INTO logs (event_code, date_time, description, parameters, notifications) VALUES ($1, $2, $3, $4, $5)", entry.EventCode, entry.DateTime, entry.Description, entry.Parameters, entry.Notifications).Scan(&Log_Response)
// 		if result != nil {
// 			log.Printf("Error storing log data in PostgreSQL: %v", result)

// 		}
// 	}

// 	// Send a success response
// 	return c.JSON(fiber.Map{"message": "Log data inserted successfully"})

// }

// // parseLogEntries parses log entries and extracts relevant fields.
// func parseLogNotification(logData string) []models.Logs {
// 	var entries []models.Logs
// 	lines := strings.Split(logData, "\n")
// 	var currentEntry models.Logs

// 	for _, line := range lines {
// 		if strings.HasPrefix(line, "EVENT CODE:") {
// 			currentEntry.EventCode = strings.TrimSpace(strings.TrimPrefix(line, "EVENT CODE:"))
// 		} else if strings.HasPrefix(line, "DATE/TIME:") {
// 			currentEntry.DateTime = strings.TrimSpace(strings.TrimPrefix(line, "DATE/TIME:"))
// 		} else if strings.HasPrefix(line, "DESCRIPTION:") {
// 			currentEntry.Description = strings.TrimSpace(strings.TrimPrefix(line, "DESCRIPTION:"))
// 		} else if strings.HasPrefix(line, "PARAMETERS:") {
// 			currentEntry.Parameters = strings.TrimSpace(strings.TrimPrefix(line, "PARAMETERS:"))
// 		} else if strings.HasPrefix(line, "NOTIFICATION:") {
// 			currentEntry.Notifications = strings.TrimSpace(strings.TrimPrefix(line, "NOTIFICATION:"))
// 			// Add the current entry to the slice and reset
// 			entries = append(entries, currentEntry)
// 			currentEntry = models.Logs{}
// 		}
// 	}
// 	return entries
// }

// func Get_Notification(c *fiber.Ctx) error {

// 	var logEntries []models.Logs

// 	Log_Response := models.Logs{}

// 	logFiles := []string{"ggwp/james/ediwow.go", "a.log"}

// 	for _, fileName := range logFiles {

// 		logData, err := os.ReadFile(fileName)
// 		if err != nil {
// 			log.Printf("Error reading %s: %v\n", fileName, err)
// 		} else {
// 			log.Printf("Log Notification: %s\n", fileName)
// 			entries := parseLogNotification(string(logData))
// 			logEntries = append(logEntries, entries...)
// 		}
// 	}
// 	for _, entry := range logEntries {

// 		result := database.DBConn.Debug().Raw("INSERT INTO logs (event_code, date_time, description, parameters, notifications) VALUES ($1, $2, $3, $4, $5)", entry.EventCode, entry.DateTime, entry.Description, entry.Parameters, entry.Notifications).Scan(&Log_Response)
// 		if result != nil {
// 			log.Printf("Error storing log data in PostgreSQL: %v", result)

// 		}
// 	}

// 	return c.JSON(Log_Response)

// }

// func parseLogNotification(logData string) []models.Logs {
// 	var entries []models.Logs
// 	lines := strings.Split(logData, "\n")
// 	var currentEntry models.Logs

//		for _, line := range lines {
//			if strings.HasPrefix(line, "EVENT CODE:") {
//				currentEntry.EventCode = strings.TrimSpace(strings.TrimPrefix(line, "EVENT CODE:"))
//			} else if strings.HasPrefix(line, "DATE/TIME:") {
//				currentEntry.DateTime = strings.TrimSpace(strings.TrimPrefix(line, "DATE/TIME:"))
//			} else if strings.HasPrefix(line, "DESCRIPTION:") {
//				currentEntry.Description = strings.TrimSpace(strings.TrimPrefix(line, "DESCRIPTION:"))
//			} else if strings.HasPrefix(line, "PARAMETERS:") {
//				currentEntry.Parameters = strings.TrimSpace(strings.TrimPrefix(line, "PARAMETERS:"))
//			} else if strings.HasPrefix(line, "NOTIFICATION:") {
//				currentEntry.Notifications = strings.TrimSpace(strings.TrimPrefix(line, "NOTIFICATION:"))
//				// Add the current entry to the slice and reset
//				entries = append(entries, currentEntry)
//				currentEntry = models.Logs{}
//			}
//		}
//		return entries
// //	}
// func Get_Notification(c *fiber.Ctx) error {
// 	// Create a slice to store log entries
// 	var logEntries []models.LogEntry
// 	Log_Response := models.LogEntry{}

// 	// Create an array to store log file names
// 	// display different logs you want to instore in database and display in postman
// 	logFiles := []string{"logs/notification/06-June/SystemNotification-06022023.log", "logs/notification/06-June/SystemNotification-06032023.log", "notification/06-June/SystemNotification-06072023.log", "notification/06-June/SystemNotification-06122023.log", "notification/06-June/SystemNotification-06132023.log", "notification/06-June/SystemNotification-06192023.log", "notification/06-June/SystemNotification-06272023.log"}

// 	// Loop through log files and read their content
// 	for _, fileName := range logFiles {
// 		logData, err := os.ReadFile(fileName)
// 		if err != nil {
// 			log.Printf("Error reading %s: %v\n", fileName, err)
// 		} else {
// 			// Parse log entries and add them to logEntries
// 			log.Printf("Log Notification : %s: %v\n", fileName, string(logData))
// 			entries := parseLogNotification(string(logData))
// 			logEntries = append(logEntries, entries...)
// 		}
// 	}

// 	// Insert log entries into the PostgreSQL database
// 	for _, entry := range logEntries {
// 		// Check if a record with the same date already exists
// 		if !checkDuplicateDate(entry.DateTime, db.DB) {
// 			result := db.DBConn.Debug().Raw("INSERT INTO logs (event_code, date_time, description, parameters, notifications) VALUES ($1, $2, $3, $4, $5)", entry.EventCode, entry.DateTime, entry.Description, entry.Parameters, entry.Notifications).Scan(&Log_Response)
// 			if result != nil {
// 				log.Printf("Error storing log data in PostgreSQL: %v", result)
// 			}
// 		}
// 	}

// 	// Send a success response in JSON format
// 	return c.JSON(fiber.Map{"message": "Log data inserted successfully"})
// }

// // checkDuplicateDate checks if a record with the same date already exists in the database
// func checkDuplicateDate(dateTime string, db *sql.DB) bool {
// 	var count int
// 	err := db.QueryRow("SELECT COUNT(*) FROM logs WHERE date_time = $1", dateTime).Scan(&count)
// 	if err != nil {
// 		log.Printf("Error checking for duplicate date: %v", err)
// 		return false
// 	}
// 	return count > 0
// }

// Define a struct to represent a log entry

// LogEntry represents a log entry structure.

// Database connection details

// LogEntry represents a log entry structure

// func WEW(c *fiber.Ctx) error {

// 	// Create a slice to store log entries

// 	Log_Response := models.LogNotification{}
// 	var logEntries []models.LogNotification

// 	// Create an array to store log file names
// 	logFiles := []string{
// 		// "logs/notification/06-June/SystemNotification-06022023.log",
// 		// "logs/notification/06-June/SystemNotification-06032023.log",
// 		// "logs/notification/06-June/SystemNotification-06072023.log",
// 		// "logs/notification/06-June/SystemNotification-06122023.log",
// 		// "logs/notification/06-June/SystemNotification-06132023.log",
// 		// "logs/notification/06-June/SystemNotification-06192023.log",
// 		// "logs/notification/06-June/SystemNotification-06272023.log",

// 		"ggwp/james/ediwow.log",
// 		"a.log",
// 	}

// 	// Loop through log files and read their content
// 	for _, fileName := range logFiles {
// 		logData, err := os.ReadFile(fileName)
// 		if err != nil {
// 			log.Printf("Error reading %s: %v\n", fileName, err)
// 			continue
// 		}

// 		// Parse log entries and add them to logEntries
// 		log.Printf("Log Notification: %s\n%s\n\n", fileName, string(logData))
// 		entries := parseLogNotification(string(logData))
// 		logEntries = append(logEntries, entries...)

// 		if err := db.DB.Create(&logEntries).Error; err != nil {
// 			// log.Printf("Error inserting log entries into the database: %v\n", err)
// 			log.Printf("Error reading %s: %v\n", fileName, err)
// 			// Handle the error here if needed.
// 		} else {
// 			result := db.DB.Debug().Raw("INSERT INTO logs (date_time,description,parameters,notifications,event_code) VALUES (?,?,?,?,?)", string(logData)).Scan(&Log_Response)
// 			if result != nil {
// 				log.Printf("Error storing log data in PostgreSQL: %v", result)
// 				log.Printf("Log Notification : %s: %v\n", fileName, string(logData))
// 				entries := parseLogNotification(string(logData))
// 				logEntries = append(logEntries, entries...)

// 			}

// 		}
// 	}

// 	// Insert log entries into the PostgreSQL database using GORM

// 	// Send a success response
// 	return c.Status(http.StatusOK).SendString(string(logData))

// }

// // parseLogNotification parses log entries and extracts relevant fields.
// func parseLogNotification(logData string) []models.LogNotification {
// 	var entries []models.LogNotification
// 	lines := strings.Split(logData, "\n")
// 	var currentEntry models.LogNotification

// 	for _, line := range lines {
// 		if strings.HasPrefix(line, "EVENT CODE:") {
// 			currentEntry.EventCode = strings.TrimSpace(strings.TrimPrefix(line, "EVENT CODE:"))
// 		} else if strings.HasPrefix(line, "DATE/TIME:") {
// 			currentEntry.DateTime = strings.TrimSpace(strings.TrimPrefix(line, "DATE/TIME:"))
// 		} else if strings.HasPrefix(line, "DESCRIPTION:") {
// 			currentEntry.Description = strings.TrimSpace(strings.TrimPrefix(line, "DESCRIPTION:"))
// 		} else if strings.HasPrefix(line, "PARAMETERS:") {
// 			currentEntry.Parameters = strings.TrimSpace(strings.TrimPrefix(line, "PARAMETERS:"))
// 		} else if strings.HasPrefix(line, "NOTIFICATION:") {
// 			currentEntry.Notifications = strings.TrimSpace(strings.TrimPrefix(line, "NOTIFICATION:"))
// 			// Add the current entry to the slice and reset
// 			entries = append(entries, currentEntry)
// 			currentEntry = models.LogNotification{}
// 		}
// 	}
// 	return entries
// }

// func Database(c *fiber.Ctx) error {
// 	userResponse := models.Logss{}
// 	logFiles := []string{"a.log", "ggwp/james/ediwow.log"}
// 	var combinedLogs strings.Builder

// 	for _, fileName := range logFiles {
// 		logData, err := os.ReadFile(fileName)
// 		if err != nil {
// 			combinedLogs.WriteString(fmt.Sprintf("Error reading %s: %v\n", fileName, err))
// 		} else {
// 			combinedLogs.WriteString(fmt.Sprintf("Log file: %s\n%s\n\n", fileName, string(logData)))

// 			result := db.DB.Debug().Raw("INSERT INTO logs (date,end_date) VALUES (?,?)", string(logData)).Scan(&userResponse)

// 			if result != nil {
// 				log.Printf("Error storing log data in PostgreSQL: %v", err)

// 				db.DB.Find(&combinedLogs)
// 			}
// 		}
// 	}
// 	return c.Status(http.StatusOK).SendString(combinedLogs.String())

// }

func GGWP222(c *fiber.Ctx) error {
	var transactions []models.LogNotification

	// Define your PostgreSQL connection string

	// Define a route to process log files

	logFile := "ggwp/james/ediwow.log" // Replace with the path to your log file

	logData, err := os.ReadFile(logFile)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file: %v", err))
	}

	// Extract EVENT CODE, DATE/TIME, and DESCRIPTION from the log data using regular expressions
	// eventCodeRegex := regexp.MustCompile("EVENT CODE: (\\d+)")
	// dateTimeRegex := regexp.MustCompile("DATE/TIME: ([^\\n]+)")

	eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
	dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
	descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")

	eventCode := eventCodeRegex.FindStringSubmatch(string(logData))
	dateTime := dateTimeRegex.FindStringSubmatch(string(logData))
	description := descriptionRegex.FindStringSubmatch(string(logData))

	if len(eventCode) < 2 || len(dateTime) < 2 || len(description) < 2 {
		return c.Status(fiber.StatusNotFound).SendString("Event information not found in log file")
	}

	Event_code := eventCode[1]
	Date_time := dateTime[1]
	Description := description[1]

	// // Insert the extracted values into the PostgreSQL database
	// _, err = db.DB.Debug().Raw("INSERT INTO your_table (event_code, date_time, description) VALUES ($1, $2, $3)", eventCodeValue, dateTimeValue, descriptionValue)
	// if err != nil {
	// 	return c.Status(fiber.StatusInternalServerError).SendString(fmt.Sprintf("Error inserting event information into PostgreSQL: %v", err))
	// }

	result := db.DB.Debug().Raw("INSERT INTO logs (event_code, date_time, description) VALUES ($1, $2, $3)", Event_code, Date_time, Description).Scan(&transactions)

	if result.Error != nil {

		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"error": "Transactions not founds",
		})
	}

	return c.SendString(fmt.Sprintf("Event information has been inserted into the database\nEvent Code: %s\nDate/Time: %s\nDescription: %s", Event_code, Date_time, Description))

}

func JPL(c *fiber.Ctx) error {
	var transactions []models.LogNotification

	// Define a route to process log files and insert data into the database

	logFiles := []string{"ggwp/james/ediwow.log", "a.log", "gg.log"} // Replace with the paths to your log files
	var insertedData []string

	for _, logFile := range logFiles {
		logData, err := os.ReadFile(logFile)
		if err != nil {
			return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file %s: %v", logFile, err))
		}

		// Extract EVENT CODE, DATE/TIME, and DESCRIPTION from the log data using regular expressions
		eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
		dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
		descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")

		eventCode := eventCodeRegex.FindStringSubmatch(string(logData))
		dateTime := dateTimeRegex.FindStringSubmatch(string(logData))
		description := descriptionRegex.FindStringSubmatch(string(logData))

		if len(eventCode) < 2 || len(dateTime) < 2 || len(description) < 2 {
			continue // Skip log files without the required information
		}

		EventCode := eventCode[1]
		DateTime := dateTime[1]
		Description := description[1]

		result := db.DB.Debug().Raw("INSERT INTO logs (event_code, date_time, description) VALUES ($1, $2, $3)", EventCode, DateTime, Description).Scan(&transactions)

		if result.Error != nil {

			return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
				"error": "Transactions not founds",
			})
		}
		// Append the inserted data to the result slice
		insertedData = append(insertedData, fmt.Sprintf("File: %s\nEvent Code: %s\nDate/Time: %s\nDescription: %s", logFile, EventCode, DateTime, Description))
	}

	// Join the inserted data into a single string and return it
	result := strings.Join(insertedData, "\n\n")
	return c.SendString(result)

}

func JPL1(c *fiber.Ctx) error {
	var transactions []models.LogNotification

	// Define a route to process log files and insert data into the database

	logFiles := []string{"ggwp/james/ediwow.log", "a.log", "gg.log"} // Replace with the paths to your log files
	var insertedData []string

	// Define the target date for filtering
	targetDate := time.Date(2019, 6, 2, 0, 0, 0, 0, time.UTC) // Replace with your target date

	for _, logFile := range logFiles {
		logData, err := os.ReadFile(logFile)
		if err != nil {
			return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file %s: %v", logFile, err))
		}

		// Extract EVENT CODE, DATE/TIME, and DESCRIPTION from the log data using regular expressions
		eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
		dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
		descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")

		eventCodeMatches := eventCodeRegex.FindAllStringSubmatch(string(logData), -1)
		dateTimeMatches := dateTimeRegex.FindAllStringSubmatch(string(logData), -1)
		descriptionMatches := descriptionRegex.FindAllStringSubmatch(string(logData), -1)

		// Ensure the number of matches is consistent for all fields
		if len(eventCodeMatches) != len(dateTimeMatches) || len(dateTimeMatches) != len(descriptionMatches) {
			continue // Skip log files with inconsistent data
		}

		// Process each match
		for i := 0; i < len(eventCodeMatches); i++ {
			eventCode := eventCodeMatches[i][1]
			dateTime := dateTimeMatches[i][1]
			description := descriptionMatches[i][1]

			// Parse the log date and compare it with the target date
			logDate, err := time.Parse(time.RFC3339, dateTime)
			if err != nil {
				continue // Skip if date parsing fails
			}

			// Compare the log date with the target date
			if logDate.After(targetDate) || logDate.Equal(targetDate) {
				// Insert the data into the database
				result := db.DB.Debug().Raw("INSERT INTO logs (event_code, date_time, description) VALUES ($1, $2, $3)", eventCode, dateTime, description).Scan(&transactions)

				if result.Error != nil {
					return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
						"error": "Transactions not found",
					})
				}

				// Append the inserted data to the result slice
				insertedData = append(insertedData, fmt.Sprintf("File: %s\nEvent Code: %s\nDate/Time: %s\nDescription: %s", logFile, eventCode, dateTime, description))
			}
		}
	}

	// Join the inserted data into a single string and return it
	result := strings.Join(insertedData, "\n\n")
	return c.SendString(result)
}

func OPt(c *fiber.Ctx) error {

	var transactions []models.LogNotification

	// Define a route to process log files and insert data into the database

	logFiles := []string{"ggwp/james/ediwow.log", "a.log", "gg.log"} // Replace with the paths to your log files
	var insertedData []string

	for _, logFile := range logFiles {
		logData, err := os.ReadFile(logFile)
		if err != nil {
			return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file %s: %v", logFile, err))
		}

		// Extract EVENT CODE, DATE/TIME, and DESCRIPTION from the log data using regular expressions
		eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
		dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
		descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")

		eventCodeMatches := eventCodeRegex.FindStringSubmatch(string(logData))
		dateTimeMatches := dateTimeRegex.FindStringSubmatch(string(logData))
		descriptionMatches := descriptionRegex.FindStringSubmatch(string(logData))

		if len(eventCodeMatches) < 2 || len(dateTimeMatches) < 2 || len(descriptionMatches) < 2 {
			continue // Skip log files without the required information
		}

		EventCode := eventCodeMatches[1]
		DateTime := dateTimeMatches[1]
		Description := descriptionMatches[1]

		// Insert extracted data into PostgreSQL

		result := db.DB.Debug().Raw("INSERT INTO logs (event_code, date_time, description) VALUES ($1, $2, $3)", EventCode, DateTime, Description).Scan(&transactions)

		if result.Error != nil {
			return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
				"error": "Transactions not found",
			})
		}

		// Append the inserted data to the result slice
		insertedData = append(insertedData, fmt.Sprintf("File: %s\nEvent Code: %s\nDate/Time: %s\nDescription: %s", logFile, EventCode, DateTime, Description))
	}

	// Join the inserted data into a single string and return it
	result := strings.Join(insertedData, "\n\n")
	return c.SendString(result)

}

func JPL5(c *fiber.Ctx) error {
	var transactions []models.LogNotification

	// Define a route to process log files and insert data into the database

	logFiles := []string{"ggwp/james/ediwow.log", "a.log", "gg.log"} // Replace with the paths to your log files
	var insertedData []string

	for _, logFile := range logFiles {
		logData, err := os.ReadFile(logFile)
		if err != nil {
			return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file %s: %v", logFile, err))
		}

		// Extract EVENT CODE, DATE/TIME, DESCRIPTION, PARAMETERS, and NOTIFICATIONS from the log data using regular expressions
		eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
		dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
		descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")
		parametersRegex := regexp.MustCompile("PARAMETERS: (.+)")
		notificationRegex := regexp.MustCompile("NOTIFICATION: (.+)")

		eventCode := eventCodeRegex.FindStringSubmatch(string(logData))
		dateTime := dateTimeRegex.FindStringSubmatch(string(logData))
		description := descriptionRegex.FindStringSubmatch(string(logData))
		parameters := parametersRegex.FindStringSubmatch(string(logData))
		notification := notificationRegex.FindStringSubmatch(string(logData))

		if len(eventCode) < 2 || len(dateTime) < 2 || len(description) < 2 || len(parameters) < 2 || len(notification) < 2 {
			continue // Skip log files without the required information
		}

		EventCode := eventCode[1]
		DateTime := dateTime[1]
		Description := description[1]
		Parameters := parameters[1]
		Notifications := notification[1]

		result := db.DB.Debug().Raw("INSERT INTO logs (event_code, date_time, description, parameters, notifications) VALUES ($1, $2, $3, $4, $5)", EventCode, DateTime, Description, Parameters, Notifications).Scan(&transactions)

		if result.Error != nil {
			return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
				"error": "Transactions not founds",
			})
		}
		// Append the inserted data to the result slice
		insertedData = append(insertedData, fmt.Sprintf("File: %s\nEvent Code: %s\nDate/Time: %s\nDescription: %s\nParameters: %s\nNotifications: %s", logFile, EventCode, DateTime, Description, Parameters, Notifications))
	}

	// Join the inserted data into a single string and return it
	result := strings.Join(insertedData, "\n\n")
	return c.SendString(result)
}

func JPL6(c *fiber.Ctx) error {
	var transactions []models.LogNotification

	// Define a route to process log files and insert data into the database

	logFiles := []string{"ggwp/james/ediwow.log", "a.log", "gg.log"} // Replace with the paths to your log files
	var insertedData []string

	for _, logFile := range logFiles {
		logData, err := os.ReadFile(logFile)
		if err != nil {
			return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file %s: %v", logFile, err))
		}

		// Extract EVENT CODE, DATE/TIME, DESCRIPTION, PARAMETERS, and NOTIFICATIONS from the log data using regular expressions
		eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
		dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
		descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")
		parametersRegex := regexp.MustCompile("PARAMETERS: (.+)")
		notificationRegex := regexp.MustCompile("NOTIFICATION: (.+)")

		eventCodes := eventCodeRegex.FindStringSubmatch(string(logData))
		dateTimes := dateTimeRegex.FindStringSubmatch(string(logData))
		descriptions := descriptionRegex.FindStringSubmatch(string(logData))
		parameters := parametersRegex.FindStringSubmatch(string(logData))
		notifications := notificationRegex.FindStringSubmatch(string(logData))

		// Create variables to store multiple occurrences of each data type
		var EventCodes, DateTimes, Descriptions, Parameters, Notifications []string

		for i := 1; i < len(eventCodes); i++ {
			EventCodes = append(EventCodes, eventCodes[i])
		}

		for i := 1; i < len(dateTimes); i++ {
			DateTimes = append(DateTimes, dateTimes[i])
		}

		for i := 1; i < len(descriptions); i++ {
			Descriptions = append(Descriptions, descriptions[i])
		}

		for i := 1; i < len(parameters); i++ {
			Parameters = append(Parameters, parameters[i])
		}

		for i := 1; i < len(notifications); i++ {
			Notifications = append(Notifications, notifications[i])
		}

		// Insert the extracted data into the database
		for i := 0; i < len(EventCodes); i++ {
			result := db.DB.Debug().Raw("INSERT INTO logs (event_code, date_time, description, parameters, notifications) VALUES ($1, $2, $3, $4, $5)",
				EventCodes[i], DateTimes[i], Descriptions[i], Parameters[i], Notifications[i]).Scan(&transactions)

			if result.Error != nil {
				return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
					"error": "Transactions not found",
				})
			}
		}

		// Append the inserted data to the result slice
		for i := 0; i < len(EventCodes); i++ {
			insertedData = append(insertedData, fmt.Sprintf("File: %s\nEvent Code: %s\nDate/Time: %s\nDescription: %s\nParameters: %s\nNotifications: %s", logFile, EventCodes[i], DateTimes[i], Descriptions[i], Parameters[i], Notifications[i]))
		}
	}

	// Join the inserted data into a single string and return it
	result := strings.Join(insertedData, "\n\n")
	return c.SendString(result)
}

func JPL7(c *fiber.Ctx) error {
	var transactions []models.LogNotification

	// Define a route to process log files and insert data into the database

	logFiles := []string{"ggwp/james/ediwow.log", "a.log", "gg.log"} // Replace with the paths to your log files
	var insertedData []string

	for _, logFile := range logFiles {
		logData, err := os.ReadFile(logFile)
		if err != nil {
			return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file %s: %v", logFile, err))
		}

		// Extract EVENT CODE, DATE/TIME, DESCRIPTION, PARAMETERS, and NOTIFICATIONS from the log data using regular expressions
		eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
		dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
		descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")
		parametersRegex := regexp.MustCompile("PARAMETERS: (.+)")
		notificationRegex := regexp.MustCompile("NOTIFICATION: (.+)")

		eventCodes := eventCodeRegex.FindAllStringSubmatch(string(logData), -1)
		dateTimes := dateTimeRegex.FindAllStringSubmatch(string(logData), -1)
		descriptions := descriptionRegex.FindAllStringSubmatch(string(logData), -1)
		parameters := parametersRegex.FindAllStringSubmatch(string(logData), -1)
		notifications := notificationRegex.FindAllStringSubmatch(string(logData), -1)

		// Loop through the extracted data and insert it into the database
		for i := range eventCodes {
			eventCode := eventCodes[i][1]
			dateTime := dateTimes[i][1]
			description := descriptions[i][1]
			parameter := parameters[i][1]
			notification := notifications[i][1]

			// Insert the data into the database
			result := db.DB.Debug().Raw("INSERT INTO logs (event_code, date_time, description, parameters, notifications) VALUES (?, ?, ?, ?, ?)",
				eventCode, dateTime, description, parameter, notification).Scan(&transactions)

			if result.Error != nil {
				return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
					"error": "Transactions not found",
				})
			}

			// Append the inserted data to the result slice
			insertedData = append(insertedData, fmt.Sprintf("File: %s\nEvent Code: %s\nDate/Time: %s\nDescription: %s\nParameters: %s\nNotifications: %s", logFile, eventCode, dateTime, description, parameter, notification))
		}
	}

	// Join the inserted data into a single string and return it
	result := strings.Join(insertedData, "\n\n")
	return c.SendString(result)
}

func JPL8(c *fiber.Ctx) error {
	var transactions []models.LogNotification

	// Define a route to process log files and insert data into the database
	logFiles := []string{"ggwp/james/ediwow.log", "a.log", "gg.log"} // Replace with the paths to your log files
	var insertedData []string

	for _, logFile := range logFiles {
		logData, err := os.ReadFile(logFile)
		if err != nil {
			return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file %s: %v", logFile, err))
		}

		// Extract EVENT CODE, DATE/TIME, DESCRIPTION, PARAMETERS, and NOTIFICATIONS from the log data using regular expressions
		eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
		dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
		descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")
		parametersRegex := regexp.MustCompile("PARAMETERS: (.+)")
		notificationRegex := regexp.MustCompile("NOTIFICATION: (.+)")

		eventCodes := eventCodeRegex.FindAllStringSubmatch(string(logData), -1)
		dateTimes := dateTimeRegex.FindAllStringSubmatch(string(logData), -1)
		descriptions := descriptionRegex.FindAllStringSubmatch(string(logData), -1)
		parameters := parametersRegex.FindAllStringSubmatch(string(logData), -1)
		notifications := notificationRegex.FindAllStringSubmatch(string(logData), -1)

		// Loop through the extracted data and insert it into the database
		for i := range eventCodes {
			eventCode := eventCodes[i][1]
			dateTime := dateTimes[i][1]
			description := descriptions[i][1]
			parameter := parameters[i][1]
			notification := notifications[i][1]

			// Parse the date/time string into a time.Time object
			parsedTime, err := time.Parse("2006-01-02 15:04:05", dateTime)
			if err != nil {
				return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error parsing date/time: %v", err))
			}

			// You can filter by date and time here (for example, only insert data from a specific date/time range)
			// if parsedTime.Before(someStartTime) || parsedTime.After(someEndTime) {
			//   continue // Skip this log entry
			// }

			// Insert the data into the database
			result := db.DB.Debug().Exec(`
				INSERT INTO logs (event_code, date_time, description, parameters, notifications)
				VALUES (?, ?, ?, ?, ?)`,
				eventCode, parsedTime, description, parameter, notification).Scan(&transactions)

			if result.Error != nil {
				return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
					"error": "Transactions not found",
				})
			}

			// Append the inserted data to the result slice
			insertedData = append(insertedData, fmt.Sprintf("File: %s\nEvent Code: %s\nDate/Time: %s\nDescription: %s\nParameters: %s\nNotifications: %s", logFile, eventCode, dateTime, description, parameter, notification))
		}
	}

	// Join the inserted data into a single string and return it
	result := strings.Join(insertedData, "\n\n")
	return c.SendString(result)
}

func JPL9(c *fiber.Ctx) error {
	// Parse query parameters
	dateFilter := c.Query("date", "")
	eventCodeFilter := c.Query("event_code", "")

	var transactions []models.LogNotification

	// Define a route to process log files and insert data into the database

	logFiles := []string{"ggwp/james/ediwow.log", "a.log", "gg.log"} // Replace with the paths to your log files
	var insertedData []string

	for _, logFile := range logFiles {
		logData, err := os.ReadFile(logFile)
		if err != nil {
			return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file %s: %v", logFile, err))
		}

		// Extract EVENT CODE, DATE/TIME, DESCRIPTION, PARAMETERS, and NOTIFICATIONS from the log data using regular expressions
		eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
		dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
		descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")
		parametersRegex := regexp.MustCompile("PARAMETERS: (.+)")
		notificationRegex := regexp.MustCompile("NOTIFICATION: (.+)")

		eventCodes := eventCodeRegex.FindAllStringSubmatch(string(logData), -1)
		dateTimes := dateTimeRegex.FindAllStringSubmatch(string(logData), -1)
		descriptions := descriptionRegex.FindAllStringSubmatch(string(logData), -1)
		parameters := parametersRegex.FindAllStringSubmatch(string(logData), -1)
		notifications := notificationRegex.FindAllStringSubmatch(string(logData), -1)

		// Loop through the extracted data and insert it into the database
		for i := range eventCodes {
			eventCode := eventCodes[i][1]
			dateTime := dateTimes[i][1]
			description := descriptions[i][1]
			parameter := parameters[i][1]
			notification := notifications[i][1]

			// Apply filters if provided
			if (dateFilter == "" || dateTime == dateFilter) && (eventCodeFilter == "" || eventCode == eventCodeFilter) {
				// Insert the data into the database
				result := db.DB.Debug().Raw("INSERT INTO logs (event_code, date_time, description, parameters, notifications) VALUES (?, ?, ?, ?, ?)",
					eventCode, dateTime, description, parameter, notification).Scan(&transactions)

				if result.Error != nil {
					return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
						"error": "Transactions not found",
					})
				}

				// Append the inserted data to the result slice
				insertedData = append(insertedData, fmt.Sprintf("File: %s\nEvent Code: %s\nDate/Time: %s\nDescription: %s\nParameters: %s\nNotifications: %s", logFile, eventCode, dateTime, description, parameter, notification))
			}
		}
	}

	// Join the inserted data into a single string and return it
	result := strings.Join(insertedData, "\n\n")
	return c.SendString(result)
}

// func JPL10(c *fiber.Ctx) error {
// 	// Parse query parameters
// 	dateFilter := c.Query("date", "")
// 	eventCodeFilter := c.Query("event_code", "")

// 	var transactions []models.LogNotification

// 	// Define a route to process log files and insert data into the database
// 	logFiles := []string{"ggwp/james/ediwow.log", "a.log", "gg.log"} // Replace with the paths to your log files
// 	var insertedData []string

// 	for _, logFile := range logFiles {
// 		logData, err := os.ReadFile(logFile)
// 		if err != nil {
// 			return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file %s: %v", logFile, err))
// 		}

// 		// Extract EVENT CODE, DATE/TIME, DESCRIPTION, PARAMETERS, and NOTIFICATIONS from the log data using regular expressions
// 		eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
// 		dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
// 		descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")
// 		parametersRegex := regexp.MustCompile("PARAMETERS: (.+)")
// 		notificationRegex := regexp.MustCompile("NOTIFICATION: (.+)")

// 		eventCodes := eventCodeRegex.FindAllStringSubmatch(string(logData), -1)
// 		dateTimes := dateTimeRegex.FindAllStringSubmatch(string(logData), -1)
// 		descriptions := descriptionRegex.FindAllStringSubmatch(string(logData), -1)
// 		parameters := parametersRegex.FindAllStringSubmatch(string(logData), -1)
// 		notifications := notificationRegex.FindAllStringSubmatch(string(logData), -1)

// 		// Loop through the extracted data and insert it into the database
// 		for i := range eventCodes {
// 			eventCode := eventCodes[i][1]
// 			dateTime := dateTimes[i][1]
// 			description := descriptions[i][1]
// 			parameter := parameters[i][1]
// 			notification := notifications[i][1]

// 			// Apply filters if provided
// 			if (dateFilter == "" || dateTime == dateFilter) && (eventCodeFilter == "" || eventCode == eventCodeFilter) {
// 				// Insert the data into the database
// 				result := db.DB.Debug().Raw("INSERT INTO logs (event_code, date_time, description, parameters, notifications) VALUES (?, ?, ?, ?, ?)",
// 					eventCode, dateTime, description, parameter, notification).Scan(&transactions)

// 				if result.Error != nil {
// 					return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
// 						"error": "Transactions not found",
// 					})
// 				}

// 				// Append the inserted data to the result slice
// 				insertedData = append(insertedData, fmt.Sprintf("File: %s\nEvent Code: %s\nDate/Time: %s\nDescription: %s\nParameters: %s\nNotifications: %s", logFile, eventCode, dateTime, description, parameter, notification))
// 			}
// 		}
// 	}

// 	// Join the inserted data into a single string and return it
// 	result := strings.Join(insertedData, "\n\n")
// 	return c.SendString(result)
// }

// filter code log file body parser

func JPL10(c *fiber.Ctx) error {
	// Parse request body

	var req models.LogRequest

	if err := c.BodyParser(&req); err != nil {
		return c.Status(http.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	var transactions []models.LogNotification

	// Define a route to process log files and insert data into the database
	logFiles := []string{"ggwp/james/ediwow.log", "a.log", "gg.log"} // Replace with the paths to your log files
	var insertedData []string

	for _, logFile := range logFiles {
		logData, err := os.ReadFile(logFile)
		if err != nil {
			return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file %s: %v", logFile, err))
		}

		// Extract EVENT CODE, DATE/TIME, DESCRIPTION, PARAMETERS, and NOTIFICATIONS from the log data using regular expressions
		eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
		dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
		descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")
		parametersRegex := regexp.MustCompile("PARAMETERS: (.+)")
		notificationRegex := regexp.MustCompile("NOTIFICATION: (.+)")

		eventCodes := eventCodeRegex.FindAllStringSubmatch(string(logData), -1)
		dateTimes := dateTimeRegex.FindAllStringSubmatch(string(logData), -1)
		descriptions := descriptionRegex.FindAllStringSubmatch(string(logData), -1)
		parameters := parametersRegex.FindAllStringSubmatch(string(logData), -1)
		notifications := notificationRegex.FindAllStringSubmatch(string(logData), -1)

		// Loop through the extracted data and insert it into the database
		for i := range eventCodes {
			eventCode := eventCodes[i][1]
			dateTime := dateTimes[i][1]
			description := descriptions[i][1]
			parameter := parameters[i][1]
			notification := notifications[i][1]

			// Apply filters if provided
			if (req.DateFilter == "" || dateTime == req.DateFilter) && (req.EventCodeFilter == "" || eventCode == req.EventCodeFilter) {
				// Insert the data into the database
				result := db.DB.Debug().Raw("INSERT INTO log_notification (event_code, date_time, description, parameters, notifications) VALUES (?, ?, ?, ?, ?)",
					eventCode, dateTime, description, parameter, notification).Scan(&transactions)

				// if result.Error != nil {
				// 	return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
				// 		"error": "Transactions not found",
				// 	})
				// }
				if result.Error != nil {
					// Check if the error is a unique constraint violation
					if strings.Contains(result.Error.Error(), "duplicate key value violates unique constraint") {
						// Handle duplicate entry error here
						// You can log the error, return an appropriate response, or take any other action
						return c.Status(http.StatusConflict).JSON(fiber.Map{
							"error": "Duplicate Data",
						})
					}
					return c.Status(http.StatusInternalServerError).JSON(fiber.Map{
						"error": "Internal server error",
					})
				}

				// Append the inserted data to the result slice
				insertedData = append(insertedData, fmt.Sprintf("File: %s\nEvent Code: %s\nDate/Time: %s\nDescription: %s\nParameters: %s\nNotifications: %s", logFile, eventCode, dateTime, description, parameter, notification))
			}
		}
	}

	// Join the inserted data into a single string and return it
	result := strings.Join(insertedData, "\n\n")
	return c.SendString(result)
}

func JPL11(c *fiber.Ctx) error {
	// Parse request body

	log.Println("Start System Notifications")
	systemNotification := &payload.SystemNotificationISO20022{}
	if parsErr := c.BodyParser(systemNotification); parsErr != nil {
		return c.Status(500).SendString(parsErr.Error())
	}

	eventCode := systemNotification.Body.Body.SystemNotification.EventCode
	eventDateTime := systemNotification.Body.Body.SystemNotification.EvenTime
	eventDescription, _ := xml.Marshal(systemNotification.Body.Body.SystemNotification.EventDescription)
	notificationParams, _ := xml.Marshal(systemNotification.Body.Body.SystemNotification.EventParams)
	notification, marshalErr := xml.Marshal(systemNotification)
	if marshalErr != nil {
		return c.Status(400).SendString(marshalErr.Error())
	}

	loggers.SystemNotificationLogger(c.Path(), eventCode, eventDateTime, string(eventDescription), string(notificationParams), string(notification))

	var req models.LogRequest

	if err := c.BodyParser(&req); err != nil {
		return c.Status(http.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	// Define a route to process log files and insert data into the database
	logFiles := []string{"ggwp/james/ediwow.log", "a.log", "gg.log"} // Replace with the paths to your log files
	var insertedData []string

	for _, logFile := range logFiles {
		logData, err := os.ReadFile(logFile)
		if err != nil {
			return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file %s: %v", logFile, err))
		}

		// Extract EVENT CODE, DATE/TIME, DESCRIPTION, PARAMETERS, and NOTIFICATIONS from the log data using regular expressions
		eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
		dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
		descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")
		parametersRegex := regexp.MustCompile("PARAMETERS: (.+)")
		notificationRegex := regexp.MustCompile("NOTIFICATION: (.+)")

		eventCodes := eventCodeRegex.FindAllStringSubmatch(string(logData), -1)
		dateTimes := dateTimeRegex.FindAllStringSubmatch(string(logData), -1)
		descriptions := descriptionRegex.FindAllStringSubmatch(string(logData), -1)
		parameters := parametersRegex.FindAllStringSubmatch(string(logData), -1)
		notifications := notificationRegex.FindAllStringSubmatch(string(logData), -1)

		// Loop through the extracted data and insert it into the database
		for i := range eventCodes {
			eventCode := eventCodes[i][1]
			dateTime := dateTimes[i][1]
			description := descriptions[i][1]
			parameter := parameters[i][1]
			notification := notifications[i][1]

			// Apply filters if provided
			if (req.DateFilter == "" || dateTime == req.DateFilter) && (req.EventCodeFilter == "" || eventCode == req.EventCodeFilter) {
				// Insert the data into the database

				// Append the inserted data to the result slice
				insertedData = append(insertedData, fmt.Sprintf("File: %s\nEvent Code: %s\nDate/Time: %s\nDescription: %s\nParameters: %s\nNotifications: %s", logFile, eventCode, dateTime, description, parameter, notification))
			}
		}
	}

	// Join the inserted data into a single string and return it
	result := strings.Join(insertedData, "\n\n")
	return c.SendString(result)
}

func SystemNotificationLogger(class, eventCode, eventDateTime, description, parameter, notification string) error {
	currentTime := time.Now()
	folderName := fmt.Sprintf("./logs/notification/%s", currentTime.Format("01-January"))
	err := os.MkdirAll(folderName, os.ModePerm)
	if err != nil {
		log.Fatal(err)
	}

	logFileName := fmt.Sprintf("%s/SystemNotification-%s.log", folderName, currentTime.Format("01022006-150405"))
	file, err := os.OpenFile(logFileName, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
	if err != nil {
		log.Fatal(err)
	}

	InfoLogger := log.New(file, "INFO: ", log.Ldate|log.Ltime)
	Separator := log.New(file, "", log.Ldate|log.Ltime)

	removeString := strings.Replace(parameter, "<string>", " ", -1)
	parameter = strings.Replace(removeString, "</string>", ",", -1)

	if description == "" {
		description = "NO DESCRIPTION"
	} else {
		removeDescriptionString := strings.Replace(description, "<string>", "", -1)
		description = strings.Replace(removeDescriptionString, "</string>", "", -1)
	}

	Separator.Println("")
	InfoLogger.Println(class + ": - - - - NOTIFICATION - - - -")
	InfoLogger.Println(class + ": EVENT CODE: " + eventCode)
	InfoLogger.Println(class + ": DATE/TIME: " + eventDateTime)
	InfoLogger.Println(class + ": DESCRIPTION: " + description)
	InfoLogger.Println(class + ": PARAMETERS: " + parameter)
	InfoLogger.Println(class + ": NOTIFICATION: " + notification)
	defer file.Close()

	return nil
}

func JPL16(c *fiber.Ctx) error {
	// Parse request body
	var req models.LogRequest

	if err := c.BodyParser(&req); err != nil {
		return c.Status(http.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	// Define a route to process log files and insert data into the database
	logFiles := []string{"ggwp/james/ediwow.log", "a.log", "gg.log"} // Replace with the paths to your log files
	logFilePath := SystemNotificationLogger(req.Class, req.Eventcode, req.DateTime, req.Description, req.Parameters, req.Notifications)
	logFiles = append(logFiles, fmt.Sprintf("%v", logFilePath))

	var insertedData []string

	for _, logFile := range logFiles {
		logData, err := os.ReadFile(logFile)
		if err != nil {
			return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file %s: %v", logFile, err))
		}

		// Extract EVENT CODE, DATE/TIME, DESCRIPTION, PARAMETERS, and NOTIFICATIONS from the log data using regular expressions
		eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
		dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
		descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")
		parametersRegex := regexp.MustCompile("PARAMETERS: (.+)")
		notificationRegex := regexp.MustCompile("NOTIFICATION: (.+)")

		eventCodes := eventCodeRegex.FindAllStringSubmatch(string(logData), -1)
		dateTimes := dateTimeRegex.FindAllStringSubmatch(string(logData), -1)
		descriptions := descriptionRegex.FindAllStringSubmatch(string(logData), -1)
		parameters := parametersRegex.FindAllStringSubmatch(string(logData), -1)
		notifications := notificationRegex.FindAllStringSubmatch(string(logData), -1)

		// Loop through the extracted data and insert it into the database
		for i := range eventCodes {
			eventCode := eventCodes[i][1]
			dateTime := dateTimes[i][1]
			description := descriptions[i][1]
			parameter := parameters[i][1]
			notification := notifications[i][1]

			// Apply filters if provided
			if (req.DateFilter == "" || dateTime == req.DateFilter) && (req.EventCodeFilter == "" || eventCode == req.EventCodeFilter) {
				// Insert the data into the database

				// Append the inserted data to the result slice
				insertedData = append(insertedData, fmt.Sprintf("File: %s\nEvent Code: %s\nDate/Time: %s\nDescription: %s\nParameters: %s\nNotifications: %s", logFile, eventCode, dateTime, description, parameter, notification))
			}

			// Call the SystemNotificationLogger function to log the notification data
			SystemNotificationLogger("YourClass", eventCode, dateTime, description, parameter, notification)

		}
	}

	// Join the inserted data into a single string and return it
	result := strings.Join(insertedData, "\n\n")
	return c.SendString(result)
}

//

func RR(c *fiber.Ctx) error {

	// Create or open a log file for writing
	logFile, err := os.Create("app.log")
	if err != nil {
		log.Fatal("Error opening log file:", err)
	}
	defer logFile.Close()

	// Set the log output to write to the log file
	log.SetOutput(logFile)

	// Log messages with different log levels
	log.Println("This is an informational message.")
	log.Printf("This is a formatted message with values: %s = %d\n", "count", 42)
	log.Fatal("This is a fatal error message. The program will exit.")

	return nil
}

// ----------------------------------------------------------------------------------------------------
// SYSTEM NOTIFICATION - This is the Participant's API service API endpoint for receiving SNMs from RTP
// ----------------------------------------------------------------------------------------------------
func SystemNotificationsRemake(c *fiber.Ctx) error {
	log.Println("Start System Notifications")
	systemNotification := &payload.SystemNotificationISO20022{}
	if parsErr := c.BodyParser(systemNotification); parsErr != nil {
		return c.Status(500).SendString(parsErr.Error())
	}

	eventCode := systemNotification.Body.Body.SystemNotification.EventCode
	eventDateTime := systemNotification.Body.Body.SystemNotification.EvenTime

	eventDescription, _ := xml.Marshal(systemNotification.Body.Body.SystemNotification.EventDescription)
	notificationParams, _ := xml.Marshal(systemNotification.Body.Body.SystemNotification.EventParams)
	notification, marshalErr := xml.Marshal(systemNotification)
	if marshalErr != nil {
		return c.Status(400).SendString(marshalErr.Error())
	}

	loggers.SystemNotificationLogger(c.Path(), eventCode, eventDateTime, string(eventDescription), string(notificationParams), string(notification))
	return c.SendStatus(204)
}

func JPL17(c *fiber.Ctx) error {

	var req models.LogRequest

	if err := c.BodyParser(&req); err != nil {
		return c.Status(http.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	logFiles := []string{"ggwp/james/ediwow.log", "a.log", "gg.log"}
	var insertedData []string

	for _, logFile := range logFiles {
		logData, err := os.ReadFile(logFile)
		if err != nil {
			return c.Status(http.StatusInternalServerError).SendString(fmt.Sprintf("Error reading log file %s: %v", logFile, err))
		}

		eventCodeRegex := regexp.MustCompile(`EVENT CODE: (\d+)`)
		dateTimeRegex := regexp.MustCompile(`DATE/TIME: ([^\n]+)`)
		descriptionRegex := regexp.MustCompile("DESCRIPTION: (.+)")
		parametersRegex := regexp.MustCompile("PARAMETERS: (.+)")
		notificationRegex := regexp.MustCompile("NOTIFICATION: (.+)")

		eventCodes := eventCodeRegex.FindAllStringSubmatch(string(logData), -1)
		dateTimes := dateTimeRegex.FindAllStringSubmatch(string(logData), -1)
		descriptions := descriptionRegex.FindAllStringSubmatch(string(logData), -1)
		parameters := parametersRegex.FindAllStringSubmatch(string(logData), -1)
		notifications := notificationRegex.FindAllStringSubmatch(string(logData), -1)

		for i := range eventCodes {
			eventCode := eventCodes[i][1]
			dateTime := dateTimes[i][1]
			description := descriptions[i][1]
			parameter := parameters[i][1]
			notification := notifications[i][1]

			if (req.DateFilter == "" || dateTime == req.DateFilter) && (req.EventCodeFilter == "" || eventCode == req.EventCodeFilter) {

				insertedData = append(insertedData, fmt.Sprintf("File: %s\nEvent Code: %s\nDate/Time: %s\nDescription: %s\nParameters: %s\nNotifications: %s", logFile, eventCode, dateTime, description, parameter, notification))
			}
		}
	}
	result := strings.Join(insertedData, "\n\n")
	return c.SendString(result)
}

func CC(c *fiber.Ctx) error {

	// Get the current date and time
	now := time.Now()

	// Create a folder name based on year and month
	folderName := "./gg/notification/" + now.Format("01-January")
	// folderName := now.Format("2006-01")
	err := os.MkdirAll(folderName, os.ModePerm)
	if err != nil {
		log.Fatal(err)
	}

	// Create a log file based on the current date and time
	logFileName := now.Format("2006-01-02 15-04-05") + ".log"
	logFile, err := os.OpenFile(folderName+"/"+logFileName, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		log.Fatal(err)
	}
	defer logFile.Close()

	// Set the log output to the log file
	log.SetOutput(logFile)

	// Log the request information
	log.Printf("[%s] %s %s", now.Format("2006-01-02 15:04:05"), c.Method(), c.Path())

	// Continue with the request
	return c.Next()

	// Define a route to log a sample request

}
