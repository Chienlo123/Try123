package routes

import (
	"sample/middleware/util"

	"github.com/gofiber/fiber/v2"
)

func SetupUserRoutes(app *fiber.App) {

	// Read all data table
	app.Get("/users", getUsers)

	app.Get("/yy", CT_Transaction)

	//Specific id
	app.Get("/users11/:id", getUser)

	// Create ng table and create another data
	app.Post("/users12345", CreateUser)

	//Registration
	app.Post("/users123", RegisterUser)

	// Update ng data sa table
	app.Patch("/users/:id", UpdateUser)

	// Delete ng data sa table
	app.Delete("/users/:id", deleteUser)

	//Cloneuser
	app.Post("/users123/:id", CloneUser)

	//XmlTry create file
	app.Get("/xmltry", XmlTry)

	//XmlTry construct root
	app.Get("/xmltry123", Xml2ndTry)

	app.Get("/xmltry12345", GetXml)

	app.Post("/gg", GG)

	//instapay struct root
	app.Get("/instapay1", Instapay1)

	//instapay http method
	app.Post("/getinstapay2", Getinstapay2)

	//instapaytry http method
	app.Post("/instapay2", Instapay2)

	//instapay http method
	// app.Post("/getinstapay3", Getinstapay3)

	// //instapaytry http method
	// app.Post("/instapay3", Instapay3)

	//instapay http method
	app.Post("/getinstapay4", Getinstapay4)

	//instapaytry http method
	app.Post("/instapay4", Instapay4)

	//token

	app.Post("/token", Token)

	app.Get("/token/:token", RetrieveData)

	app.Get("/Gene", Wew)

	app.Get("/HH", HH)
	app.Get("/Wtf", CT_Transaction)

	//
	app.Post("/gg123", Ins)
	app.Get("/ggwp123", Instapay123)

	app.Get("/CT", CT)

	app.Get("/logs", James)

	app.Post("/Post", Database)
	// app.Post("/Post123", Database123)
	// app.Get("/wew", WEW)

	app.Post("/11", JPL10)
	app.Post("/12", JPL11)

	app.Post("/16", JPL16)
	app.Post("/17", JPL17)
	app.Get("/19", SystemNotificationsRemake)
	app.Post("/20", util.InsertNotification)
	app.Get("/21", CC)

}
