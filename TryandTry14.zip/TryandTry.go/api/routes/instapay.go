package routes

import (
	"bytes"
	"encoding/xml"
	"io"
	"net/http"
	"sample/instapay4"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

func Instapay4(c *fiber.Ctx) error {

	//1stlayer

	Message := instapay4.Message{

		FIToFICstmrCdtTrf: instapay4.FIToFICstmrCdtTrf{

			GrpHdr: instapay4.GrpHdr{},

			MsgId:   instapay4.MsgId{},
			CreDtTm: instapay4.CreDtTm{},
			NbOfTxs: instapay4.NbOfTxs{},

			TtlIntrBkSttlmAmt: instapay4.TtlIntrBkSttlmAmt{

				Ccy: instapay4.Ccy{},
			},

			IntrBkSttlmDt: instapay4.IntrBkSttlmDt{},
			SttlmInf: instapay4.SttlmInf{

				SttlmMtd: instapay4.SttlmMtd{},

				ClrSys: instapay4.ClrSys{

					Cd: instapay4.Cd{},
				},
			},
			//second layer

			CdtTrfTxInf: instapay4.CdtTrfTxInf{

				PmtId: instapay4.PmtId{

					InstrId: instapay4.InstrId{},

					EndToEndId: instapay4.EndToEndId{},
					TxId:       instapay4.TxId{},
					ClrSysRef:  instapay4.ClrSysRef{},
				},
				PmtTpInf: instapay4.PmtTpInf{

					SvcLvl: instapay4.SvcLvl{

						PmtTpInf_Cd: instapay4.PmtTpInf_Cd{},
					},
					LclInstrm: instapay4.LclInstrm{

						LclInstrm_Prtry: instapay4.LclInstrm_Prtry{},
					},
					CtgyPurp: instapay4.CtgyPurp{

						CtgyPurp_Prtry: instapay4.CtgyPurp_Prtry{},
					},
				},
				IntrBkSttlmAmt: instapay4.IntrBkSttlmAmt{

					IntrBkSttlmAmt_Ccy: instapay4.IntrBkSttlmAmt_Ccy{},
				},
				ChrgBr: instapay4.ChrgBr{},
				InstgAgt: instapay4.InstgAgt{

					InstgAgt_FinInstnId: instapay4.InstgAgt_FinInstnId{

						InstgAgt_BICFI: instapay4.InstgAgt_BICFI{},
					},
				},
				InstdAgt: instapay4.InstdAgt{

					InstdAgt_FinInstnId: instapay4.InstdAgt_FinInstnId{

						InstdAgt_BICFI: instapay4.InstdAgt_BICFI{},
					},
				},
				UltmtDbtr: instapay4.UltmtDbtr{

					Nm: instapay4.Nm{},
					UltmtDbtr_Id: instapay4.UltmtDbtr_Id{

						PrvtId: instapay4.PrvtId{

							Othr: instapay4.Othr{

								Othr_Id: instapay4.Othr_Id{},
							},
						},
					},
				},
			},
		},
	}

	xmlInfo, err := xml.MarshalIndent(Message, " ", "")
	if err != nil {

		return c.Status(http.StatusInternalServerError).SendString("error generating XML response")
	}

	c.Response().Header.Set("Content-Type", "application/xml")
	return c.Send(xmlInfo)
}
func Getinstapay4(c *fiber.Ctx) error {

	TryReturn, TryErr := xml.MarshalIndent(instapay4.FIToFICstmrCdtTrf{}, "", "")

	if TryErr != nil {

		return c.SendString(TryErr.Error())
	}

	response, respErr := http.NewRequest(http.MethodPost, "http://127.0.0.1:3000/instapay4", bytes.NewBuffer(TryReturn))

	if respErr != nil {

		return c.SendString(respErr.Error())
	}

	response.Header.Set("Content-Type", "application/xml")
	client := &http.Client{}

	resp, clientErr := client.Do(response)
	if clientErr != nil {

		return c.SendString(clientErr.Error())
	}
	defer resp.Body.Close()

	respBody, readErr := io.ReadAll(resp.Body)
	if readErr != nil {

		return c.SendString(readErr.Error())
	}

	c.Set("Content-Type", "application/xml")

	return c.Send(respBody)

}

var tokenStore = make(map[string]map[string]interface{})

func Token(c *fiber.Ctx) error {

	// Route to accept input data and convert it into a token

	// Parse the input data from Postman (assuming it's JSON)
	var inputData map[string]interface{}
	if err := c.BodyParser(&inputData); err != nil {
		return err
	}

	// Generate a unique token (UUID in this example)
	token := uuid.New().String()

	// Store the token and input data in the data store
	tokenStore[token] = inputData

	// Respond with the generated token
	return c.JSON(fiber.Map{

		"dbName":   token,
		"username": token,
		"password": token,
	})

	// Route to retrieve the data associated with a token

	// Get the token from the URL parameter

}

func RetrieveData(c *fiber.Ctx) error {

	token := c.Params("token")

	// Lookup the token in the data store
	inputData, found := tokenStore[token]
	if !found {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"error": "Token not found",
		})
	}

	// Respond with the associated data
	return c.JSON(inputData)

}
