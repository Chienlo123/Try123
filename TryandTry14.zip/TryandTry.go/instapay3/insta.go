package instapay3

import "encoding/xml"

// AdmnSignOnReq
type (
	AdmnSignOnReq struct {
		XMLName            xml.Name `xml:"AdmnSignOnReq"`
		Name               string   `xml:"name"`
		ISO_Description    string   `xml:"iso_description"`
		Product_Usage      string   `xml:"product_usage"`
		Type               string   `xml:"type"`
		Occurrence         string   `xml:"occurrence"`
		GrpHdr             GrpHdr
		MsgId              MsgId
		CreDtTm            CreDtTm
		SignOnReq          SignOnReq
		InstdAgt           InstdAgt
		InstrId            InstrId
		SignOnReq_InstgAgt SignOnReq_InstgAgt
	}

	GrpHdr struct {
		XMLName         xml.Name `xml:"GrpHdr"`
		Name            string   `xml:"name"`
		ISO_Description string   `xml:"iso_description"`
		Type            string   `xml:"type"`
		Occurrence      string   `xml:"occurrence"`
	}

	MsgId struct {
		XMLName         xml.Name `xml:"MsgId"`
		Name            string   `xml:"name"`
		ISO_Description string   `xml:"iso_description"`
		Format          string   `xml:"format"`
		Example         string   `xml:"example"`
		Type            string   `xml:"type"`
		Min_MaxLen      string   `xml:"min_maxlen"`
		Occurrence      string   `xml:"occurrence"`
	}

	CreDtTm struct {
		XMLName         xml.Name `xml:"CreDTm"`
		Name            string   `xml:"name"`
		ISO_Description string   `xml:"iso_description"`
		Format          string   `xml:"format"`
		Example         string   `xml:"example"`
		Type            string   `xml:"type"`
		Rules           string   `xml:"rules"`
		Reason_Codes    string   `xml:"reason_codes"`
		Occurrence      string   `xml:"occurrence"`
	}
)

//SignOnReq

type (
	SignOnReq struct {
		XMLName    xml.Name `xml:"SignOnReg"`
		Name       string   `xml:"name"`
		Type       string   `xml:"type"`
		Occurrence string   `xml:"occurrence"`
	}

	InstrId struct {
		XMLName         xml.Name `xml:"InstrId"`
		Name            string   `xml:"name"`
		ISO_Description string   `xml:"iso_description"`
		Product_Usage   string   `xml:"product_usage"`
		Format          string   `xml:"format"`
		Example         string   `xml:"example"`
		Type            string   `xml:"type"`
		Min_MaxLen      string   `xml:"min_maxlen"`
		Rules           string   `xml:"rules"`
		Reason_Codes    string   `xml:"reason_codes"`
		Occurrence      string   `xml:"occurrence"`
	}

	SignOnReq_InstgAgt struct {
		XMLName              xml.Name `xml:"InstgAgt"`
		Name                 string   `xml:"name"`
		ISO_Description      string   `xml:"iso_description"`
		Type                 string   `xml:"type"`
		Occurrence           string   `xml:"occurrence"`
		SignOnReq_FinInstnId SignOnReq_FinInstnId
		SignOnReq_BIC        SignOnReq_BIC
	}

	SignOnReq_FinInstnId struct {
		XMLName         xml.Name `xml:"FinInstnId"`
		Name            string   `xml:"name"`
		ISO_Description string   `xml:"iso_description"`
		Type            string   `xml:"type"`
		Occurrence      string   `xml:"occurrence"`
	}

	SignOnReq_BIC struct {
		XMLName         xml.Name `xml:"BIC"`
		Name            string   `xml:"name"`
		ISO_Description string   `xml:"iso_description"`
		Product_Usage   string   `xml:"product_usage"`
		Example         string   `xml:"example"`
		RegEx           string   `xml:"regex"`
		Type            string   `xml:"type"`
		Rules           string   `xml:"rules"`
		Reason_Codes    string   `xml:"reason_codes"`
		Occurrence      string   `xml:"occurrence"`
	}
)

//InstdAgt

type (
	InstdAgt struct {
		XMLName             xml.Name `xml:"InstdAgt"`
		Name                string   `xml:"name"`
		ISO_Description     string   `xml:"iso_description"`
		Type                string   `xml:"type"`
		Occurrence          string   `xml:"occurrence"`
		InstdAgt_FinInstnId InstdAgt_FinInstnId
		InstdAgt_BIC        InstdAgt_BIC
	}

	InstdAgt_FinInstnId struct {
		XMLName         xml.Name `xml:"FinInstnId"`
		Name            string   `xml:"name"`
		ISO_Description string   `xml:"iso_description"`
		Type            string   `xml:"type"`
		Occurrence      string   `xml:"ocurrence"`
	}

	InstdAgt_BIC struct {
		XMLName         xml.Name `xml:"InstdAgt_BIC"`
		Name            string   `xml:"name"`
		ISO_Description string   `xml:"iso_description"`
		Product_Usage   string   `xml:"product_usage"`
		Example         string   `xml:"example"`
		RegEx           string   `xml:"regex"`
		Type            string   `xml:"type"`
		Rules           string   `xml:"rules"`
		Occurrence      string   `xml:"occurrence"`
	}
)
