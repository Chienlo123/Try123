package loggers

import (
	"log"
	"os"

	"strings"
	"time"
)

var (
	WarningLogger *log.Logger
	InfoLogger    *log.Logger
	ErrorLogger   *log.Logger
	Separator     *log.Logger
)

func CreateDirectory(path string) error {
	if _, err := os.Stat(path); os.IsNotExist(err) {
		err := os.MkdirAll(path, 0755)
		if err != nil {
			return err
		}
		return nil
	} else {
		return err
	}
}

func SystemNotificationLogger(class, eventCode, eventDateTime, description, parameter, notification string) {
	currentTime := time.Now()
	folderName := "./logs/notification/" + currentTime.Format("01-January")
	CreateDirectory(folderName)
	file, err := os.OpenFile(folderName+"/SystemNotification-"+currentTime.Format("01022006")+".log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
	if err != nil {
		log.Fatal(err)
	}

	InfoLogger = log.New(file, "INFO: ", log.Ldate|log.Ltime)
	Separator = log.New(file, "", log.Ldate|log.Ltime)

	removeString := strings.Replace(parameter, "<string>", " ", -1)
	parameter = strings.Replace(removeString, "</string>", ",", -1)

	if description == "" {
		description = "NO DESCRIPTION"
	} else {
		removeDescriptionString := strings.Replace(description, "<string>", "", -1)
		description = strings.Replace(removeDescriptionString, "</string>", "", -1)
	}

	Separator.Println("")
	InfoLogger.Println(class + ": - - - - NOTIFICATION - - - -")
	InfoLogger.Println(class + ": EVENT CODE: " + eventCode)
	InfoLogger.Println(class + ": DATE/TIME: " + eventDateTime)
	InfoLogger.Println(class + ": DESCRIPTION: " + description)
	InfoLogger.Println(class + ": PARAMETERS: " + parameter)
	InfoLogger.Println(class + ": NOTIFICATION: " + notification)
	defer file.Close()
}
