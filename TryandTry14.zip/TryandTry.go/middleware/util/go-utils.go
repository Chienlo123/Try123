// Package fiber provides utility functions for gofiber v2, jwt-go
// With additional validation functions, sending JSON response and parsing request bodies, getting JWT claims
package util

import (
	"encoding/xml"
	"fmt"
	"sample/model/payload"

	"github.com/gofiber/fiber/v2"
)

func InsertNotification(c *fiber.Ctx) error {
	fmt.Println("TEST INSERT NOTIFICATION")
	systemNotification := &payload.SystemNotificationISO20022{}
	if parsErr := c.BodyParser(systemNotification); parsErr != nil {
		return c.Status(500).SendString(parsErr.Error())
	}

	eventCode := systemNotification.Body.Body.SystemNotification.EventCode
	eventDateTime := systemNotification.Body.Body.SystemNotification.EvenTime

	eventDescription, _ := xml.Marshal(systemNotification.Body.Body.SystemNotification.EventDescription)
	notificationParams, _ := xml.Marshal(systemNotification.Body.Body.SystemNotification.EventParams)

	fmt.Println("Event Code:", string(eventCode))
	fmt.Println("Event Date Time:", string(eventDateTime))
	fmt.Println("Event Description:", string(eventDescription))
	fmt.Println("Event Description:", string(notificationParams))

	notification, marshalErr := xml.Marshal(systemNotification)
	if marshalErr != nil {
		return marshalErr
	}

	return c.Send(notification)
}
