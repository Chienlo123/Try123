package instapay2

import "encoding/xml"

// from

type (
	AppHdr struct {
		XMLName        xml.Name `xml:"AppHdr"`
		Name           string   `xml:"name"`
		ISODescription string   `xml:"isodescription"`
		Type           string   `xml:"type"`
		Occurence      string   `xml:"occurence"`
		Fr             Fr
		To             To
		BizMsgIdr      BizMsgIdr
		MsgDefIdr      MsgDefIdr
		CreDt          CreDt
		CpyDplct       CpyDplct
		Sgntr          Sgntr
	}

	Fr struct {
		XMLName        xml.Name `xml:"Fr"`
		Name           string   `xml:"name"`
		ISODescription string   `xml:"isodescription"`
		ProductUsage   string   `xml:"productusage"`
		Type           string   `xml:"type"`
		Occurence      string   `xml:"occurence"`
		Fr_FIId        Fr_FIId
	}

	Fr_FIId struct {
		XMLName            xml.Name `xml:"Fr_FIId"`
		Name               string   `xml:"name"`
		ISODescription     string   `xml:"isodescription"`
		Type               string   `xml:"type"`
		Occurence          string   `xml:"occurence"`
		Fr_FIId_FinInstnId Fr_FIId_FinInstnId
		Fr_FIId_BrnchId    Fr_FIId_BrnchId
	}

	Fr_FIId_FinInstnId struct {
		XMLName             xml.Name `xml:"Fr_FinInstnId"`
		Name                string   `xml:"name"`
		ISODescription      string   `xml:"isodescription"`
		Type                string   `xml:"type"`
		Occurence           string   `xml:"occurence"`
		Fr_FinInstnId_BICFI Fr_FinInstnId_BICFI
	}

	Fr_FinInstnId_BICFI struct {
		XMLName        xml.Name `xml:"Fr_BICFI"`
		Name           string   `xml:"name"`
		ISODescription string   `xml:"isodescription"`
		ProductUsage   string   `xml:"productusage"`
		Example        string   `xml:"example"`
		RegEx          string   `xml:"regex"`
		Type           string   `xml:"type"`
		Rule           string   `xml:"rule"`
		ReasonCode     string   `xml:"reasoncode"`
		Occurence      string   `xml:"occurence"`
	}
	Fr_FIId_BrnchId struct {
		XMLName            xml.Name `xml:"Fr_BrnchId"`
		Name               string   `xml:"name"`
		ISODescription     string   `xml:"isodescription"`
		ProductUsage       string   `xml:"productusage"`
		Note               string   `xml:"note"`
		Type               string   `xml:"type"`
		Occurrence         string   `xml:"occurrence"`
		Fr_FIId_BrnchId_Id Fr_FIId_BrnchId_Id
	}

	Fr_FIId_BrnchId_Id struct {
		XMLName        xml.Name `xml:"Fr_Id"`
		Name           string   `xml:"name"`
		ISODescription string   `xml:"isodescription"`
		ProductUsage   string   `xml:"productusage"`
		Note           string   `xml:"note"`
		Type           string   `xml:"type"`
		Min_MaxLen     string   `xml:"min_maxlen"`
		Occurrence     string   `xml:"occurrence"`
	}

	///To

	To struct {
		XMLName        xml.Name `xml:"To"`
		Name           string   `xml:"name"`
		ISODescription string   `xml:"isodescription"`
		ProductUsage   string   `xml:"productusage"`
		Type           string   `xml:"type"`
		Occurrence     string   `xml:"occurrence"`
		To_FIId        To_FIId
	}

	To_FIId struct {
		XMLName            xml.Name `xml:"To_FIId"`
		Name               string   `xml:"name"`
		ISODescription     string   `xml:"isodescription"`
		Type               string   `xml:"type"`
		Occurrence         string   `xml:"occurence"`
		To_FIId_FinInstnId To_FIId_FinInstnId
		To_FIId_BrnchId    To_FIId_BrnchId
	}

	To_FIId_FinInstnId struct {
		XMLName                  xml.Name `xml:"To_FinInstnId"`
		Name                     string   `xml:"name"`
		ISODescription           string   `xml:"isodescription"`
		Type                     string   `xml:"type"`
		Occurrence               string   `xml:"occurence"`
		To_FIId_FinInstnId_BICFI To_FIId_FinInstnId_BICFI
	}

	To_FIId_FinInstnId_BICFI struct {
		XMLName        xml.Name `xml:"To_BICFI"`
		Name           string   `xml:"name"`
		ISODescription string   `xml:"isodescription"`
		ProductUsage   string   `xml:"productusage"`
		Example        string   `xml:"example"`
		RegEx          string   `xml:"regex"`
		Type           string   `xml:"type"`
		Rule           string   `xml:"rule"`
		Reason         string   `xml:"reason"`
		Occurrence     string   `xml:"occurrence"`
	}

	To_FIId_BrnchId struct {
		XMLName            xml.Name `xml:"To_BrnchId"`
		Name               string   `xml:"name"`
		ISODescription     string   `xml:"isodescription"`
		ProductUsage       string   `xml:"productusage"`
		Type               string   `xml:"type"`
		Occurrence         string   `xml:"occurence"`
		To_FIId_BrnchId_Id To_FIId_BrnchId_Id
	}

	To_FIId_BrnchId_Id struct {
		XMLName        xml.Name `xml:"To_Id"`
		Name           string   `xml:"name"`
		ISODescription string   `xml:"isodescription"`
		ProductUsage   string   `xml:"productusage"`
		Note           string   `xml:"note"`
		Type           string   `xml:"type"`
		Min_MaxLen     string   `xml:"min_maxlen"`
		Rule           string   `xml:"rule"`
		ReasonCode     string   `xml:"reasoncode"`
		Occurrence     string   `xml:"occurrence"`
	}

	////Business message Identifier

	BizMsgIdr struct {
		XMLName        xml.Name `xml:"BizMsgIdr"`
		Name           string   `xml:"name"`
		ISODescription string   `xml:"isodescription"`
		ProductUsage   string   `xml:"productusage"`
		Format         string   `xml:"format"`
		Example        string   `xml:"example"`
		Type           string   `xml:"type"`
		Min_MaxLen     string   `xml:"min_maxlen"`
		Occurrence     string   `xml:"occurrence"`
	}

	MsgDefIdr struct {
		XMLName        xml.Name `xml:"MsgDefIdr"`
		Name           string   `xml:"name"`
		ISODescription string   `xml:"isodescription"`
		ProductUsage   string   `xml:"productusage"`
		Type           string   `xml:"type"`
		Min_MaxLen     string   `xml:"min_maxlen"`
		Occurrence     string   `xml:"occurence"`
	}

	CreDt struct {
		XMLName        xml.Name `xml:"CreDt"`
		Name           string   `xml:"name"`
		ISODescription string   `xml:"isodescription"`
		ProductUsage   string   `xml:"productusage"`
		Example        string   `xml:"example"`
		RegEx          string   `xml:"regex"`
		Type           string   `xml:"type"`
		Occurrence     string   `xml:"occurence"`
	}

	CpyDplct struct {
		XMLName        xml.Name `xml:"CpyDplct"`
		Name           string   `xml:"name"`
		ISODescription string   `xml:"isodescription"`
		ProductUsage   string   `xml:"productusage"`
		Example        string   `xml:"example"`
		Type           string   `xml:"type"`
		Rule           string   `xml:"rule"`
		ReasonCode     string   `xml:"reasoncode"`
		Occurrence     string   `xml:"occurence"`
	}

	Sgntr struct {
		XMLName        xml.Name `xml:"Sgntr"`
		Name           string   `xml:"name"`
		ISODescription string   `xml:"isodescription"`
		ProductUsage   string   `xml:"productusage"`
		Type           string   `xml:"type"`
		Rule           string   `xml:"rule"`
		Occurrence     string   `xml:"occurrence"`
		Any            Any
	}

	Any struct {
		XMLName    xml.Name `xml:"xs:Any"`
		Occurrence string   `xml:"occurence"`
	}
)
