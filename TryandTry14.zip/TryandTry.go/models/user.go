package models

import (
	"encoding/xml"
	"time"

	"gorm.io/gorm"
)

type User struct {
	Name     string `xml:"name"`
	Lastname string `xml:"lastname"`
	Address  string `xml:"address"`
	Contact  string `xml:"contact"`
	Email    string `xml:"email"`
	Password string `xml:"password"`
}

type User123 struct {
	Name     string `xml:"name"`
	Id       string `xml:"id"`
	Lastname string `xml:"lastname"`
	Contact  int    `xml:"contact"`
	Email    string `xml:"email"`
	Password string `xml:"password"`
}
type UsersInfo struct {
	CorporateID      string `xml:"corporate"`
	BranchID         string `xml:"branchid"`
	TransactionKey   string `xml:"transactionkey"`
	RequestRefNo     string `xml:"requestno"`
	TransactionType  string `xml:"transactiontype"`
	RequestTimeStamp string `xml:"requesttimestamp"`
	TerminalID       string `xml:"terminalid"`
	Address          string `xml:"address"`
}

type Deped struct {
	XMLName       xml.Name `xml:"DepedHead"`
	School        string   `xml:"DepedSchool"`
	PrincipalHead PrincipalHead
}

type PrincipalHead struct {
	XMLName     xml.Name `xml:"soapenv:Header"`
	Principal   string   `xml:"principal"`
	TeacherBody TeacherBody
}

type TeacherBody struct {
	XMLName xml.Name `xml:"soapenv:Body"`
	Teacher string   `xml:"teacher"`
	Student Student
}

type Student struct {
	XMLName      xml.Name `xml:"Deped:StudentInformation"`
	StudentName  string   `xml:"studentname"`
	StudentID    string   `xml:"studentid"`
	Section      string   `xml:"section"`
	MajorSubject string   `xml:"majorsubject"`
}

// type Employee struct {
// 	ID     int    `xml:"id"`
// 	Name   string `xml:"name"`
// 	Salary int    `xml:"salary"`
// }

// type User1 struct {
// 	ID       int    `xml:"primaryKey"`
// 	Name     string `xml:"unique"`
// 	Password string
// 	// Add other fields as needed
// }

type LoginResponse struct {
	XMLName xml.Name `xml:"response"`
	Message string   `xml:"message"`
}

type (
	Info struct {
		ReferenceNumber string `json:"referencenumber"`
		AccountNumber   string `json:"accountnumber"`
		StartDate       string `json:"startdate"`
		EndDate         string `json:"enddate"`
	}
)

type CT struct {
	ID                   string `xml:"id"`
	Transaction_type     string `xml:"transaction_type"`
	Status               string `xml:"status"`
	Reason_code          string `xml:"reason_code"`
	Local_instrument     string `xml:"local_instrument"`
	Instruction_id       string `xml:"instruction_id"`
	Transaction_id       string `xml:"transaction_id"`
	Reference_id         string `xml:"reference_id"`
	Sender_bic           string `xml:"sender_bic"`
	Sender_name          string `xml:"sender_name"`
	Sender_account       string `xml:"sender_account"`
	Currency             string `xml:"currency"`
	Amount               int    `xml:"amount"`
	Receiving_bic        string `xml:"receiving_bic"`
	Receiving_name       string `xml:"receiving_name"`
	Receiving_account    string `xml:"receiving_account"`
	Transaction_datetime string `xml:"transaction_datetime"`
	Bn_response          string `xml:"bn_response"`
}

//Logs

type Logss struct {
	// EventCode    string `json:"event_code"`
	// DateTime     string `json:"date/time"`
	// Description  string `json:"description"`
	// Parameters   string `json:"parameters"`
	Notification string `json:"notification"`
	// Date_Time    string `json:"date_Time"`
}

// type LogEntry struct {
// 	EventCode     int      `json:"event_code"`
// 	EventDatetime string   `json:"date/time"`
// 	Description   string   `json:"description"`
// 	Parameters    []string `json:"parameters"`
// 	Notifications string   `json:"notifications"`
// }

// type LogEntry struct {
// 	EventCode     int
// 	EventDatetime string
// 	Description   string
// 	Parameters    []string
// 	Notifications []string
// }
//

type LogEntry struct {
	EventCode     int
	EventDatetime string
	Description   string
	Parameters    []string
	Notifications string
}

// Log represents the database model for log entries
type Log struct {
	gorm.Model
	EventCode     int
	EventDatetime string
	Description   string
	Parameters    string `gorm:"type:text[]"`
	Notifications string
}

type LogNotification struct {
	gorm.Model
	Eventcode     string `json:"eventCode"`
	DateTime      string `json:"date_time"`
	Description   string `json:"description"`
	Parameters    string `json:"parameters"`
	Notifications string `json:"notifications"`
	Class         string `json:"class"`
}

type LogRequest struct {
	DateFilter      string `json:"date"`
	EventCodeFilter string `json:"event_code"`
	LogNotification
}

type Event struct {
	ID            int       `json:"id"`
	EventCode     string    `json:"event_code"`
	DateTime      time.Time `json:"date_time"`
	Description   string    `json:"description"`
	Parameters    string    `json:"parameters"`
	Notifications string    `json:"notifications"`
}
